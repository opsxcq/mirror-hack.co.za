/* convert.c by xt for omega ddos */

#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>


int main(int argc, char **argv)
{
   unsigned long convip = 0L;
   
   if (argc < 2) {
     printf("usage: convert <ip address>\n");
     exit(0);
   }

   if ((strchr(argv[1], '.')) != NULL) {
     convip = inet_addr(argv[1]);
     convip -= 2358L;
     printf("converted %s to: %lu\n", argv[1], convip);
   } else {
     (unsigned long) convip = atoi(argv[1]) + 2358L;
     printf("converted %s to: %s\n", argv[1], (char *) inet_ntoa((unsigned long) convip));
   }
   

   convip = 0L;
   
   return 1;
}
     