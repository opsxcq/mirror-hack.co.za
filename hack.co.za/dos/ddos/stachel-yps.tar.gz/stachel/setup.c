/* creates pw.h for the server */

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

char *crypt(char *,char *);

int main(int argc,char **argv) 
{
 char password[200];
 char result[200];
 FILE *pwh;
 memset(password,0,sizeof(password));
 memset(result,0,sizeof(result));

 printf("-Pre-Compilation----------------------\n");
 strcpy(password,getpass("enter the passphrase : "));
 fflush(stdout);
 printf("--------------------------------------\n");
 strcpy(result,crypt(password,"zA"));
 printf("Generated CRYPT-PW: %s\n",result);
 if((pwh=fopen("pw.h","w"))==NULL)
 {
     printf("Cannot open pw.h, aborting\n");
     exit(0x1);
 }
 fprintf(pwh,"/* created password for masterserver */\n\n");
 fprintf(pwh,"#define SALT \"%s\\0\"\n",result);
 fclose(pwh);
 printf("pw.h created..\n");      
 exit(0x0);
}

