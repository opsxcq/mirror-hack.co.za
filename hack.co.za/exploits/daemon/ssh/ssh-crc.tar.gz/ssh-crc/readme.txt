This is the exploit for the bug in file deattack.c in the portable
version of openssh-2.2.0 (and possible below).

We need to know several numbers for it to work so it's very difficult 
to use the exploit on the wild.

1. We need to know is the EXACT distance of the variable "h" to the 2 
   last bytes of the saved EIP in the stack with an increment of 2 bytes.

2. This is the number that we place instead of the two first bytes.
   (last two bytes are the first two bytes of the address)
   Example : 0x0806d3de   
	We will replace 0x0806 for the address we want, so we will replace
	0xde 0xd3 0x06 0x08 for 0xde 0xd3 0x0f 0x08
	that is the address of the buffer with the shellcode.

3. Packet Length

4. REAL packet length. The shellcode will go in the difference between this
   two lengths,as the sshd server reads 8192(?) bytes at time .

Then we need the host and the port number :) 

Finnaly we kneed a small number that doesn�t cause SEG FAULT.
It doesn�t matter how large is it as long as it doesn't cause any 
segment error.
It can be 0,1,2,3,...

Example :

./xp 30988 0 114200 117280 127.0.0.1 22 3

This works on Linux Mandrake 7.2 using "sshd -d" being debugged with GDB,
but it's possible to attach a SSHD child with GDB and find the numbers we 
need for this to work with the daemon.If the SSHD child doesn't SEG FAULT
in the beggining (we can do that easily by trying a few numbers) it will
take more than 10 seconds to process the packet and that is sufficient to
attach the process without changing its code and put a "sleep(15)" in it.

We need to be root :) for doing this ...
Finding the numbers we need without being root is very difficult.
And without no access to any user in the system at all its even more difficult.
This addresses changes with the plataform,operating system,packet length...

BUT its possible to do it (pheraps by reproducing exactly the victim environment)
and thats why i wrote this.

So as allways : "Please upgrade your software"

Get the last version of OpenSSH from : 

http://www.openssh.com


- ------------------------------------------------------------------------------------
I used a modified version of the openssh-2.3.0 (portable) SSH to produce the packet.

THIS FILES ARE FOR EDUCATIONAL PURPOSE ONLY.

Diff file to modify an ssh client for using it with the exploit :
- ------------------------------------------------------------------------------------

BlackSphere - Hugo Oliveira Dias - 20 Fev 2001

Email: bsphere@clix.pt
Homepage: http://planeta.clix.pt/bsphere

- ------------------------------------------------------------------------------------
-----BEGIN PGP SIGNATURE-----
Version: PGPfreeware 7.0.3 for non-commercial use <http://www.pgp.com>

iQA/AwUBOpK/xBmmBmSsB+85EQLAWACgzdeSqpGTpz+TklsupMD5/KUCt6UAn248
J2jw4HBHgb7MHR/vfYqMDY3l
=OD22
-----END PGP SIGNATURE-----
