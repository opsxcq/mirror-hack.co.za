#ifndef CODE_H
#define CODE_H

#define LINUX_I386 0x0
#define BSD_I386 0x1
#define ARCH_MAX 0x2

#define PORTSHELL	0x0
#define PEERNAME	0x1
#define TYPE_MAX	0x2

typedef struct c0de {
	char	*code;
	int	codesize;
} c0de;

extern c0de	*archs[];
extern char	*archs_str[],
		*code_str[];

#endif /* CODE_H */
