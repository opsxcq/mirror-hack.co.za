COMMAND

    rpc.pcnfsd

SYSTEMS AFFECTED

    AIX: 4.0, 4.1, 4.2, 4.3
    HP 9000 series 700/800
    Linux (if installed)
    OpenBSD
    OSF: 3.2
    Solaris: 2.3, 2.4, 2.5, 2.5.1, 2.6 (if additionally installed)
    SunOS: 4.1.3, 4.1.4 (if additionally installed)

PROBLEM

    Following  info  is  mosly  based  on  RSI  and Rhino9 advisories.
    PCNFSD  is  a  Remote  Procedure  Call  used by NFS clients.  This
    service  provides   username  and   password  authentication   for
    networked computers which have installed NFS client software.  Two
    vulnerabilities are covered in RSI advisory which both allow  root
    access to be compromised ('Bermuda Brian' found it).  Vulnerable
    functions are following:

    pr_init ()
    ----------
	This  function  will  create  a  spool directory for a client.
	When  passing  data  to  this  function,  it  calls  secure ()
	attempting  to  find  any  insecure  characters.   The list of
	characters that suspicious () checks for are:

	;|&<>`'!?*()[]^/

	By sending a "." as the printer name, rpc.pcnfsd will  attempt
	to make  that directory  and set  the mode  to 777.   By doing
	this,  an  attacker  sets  the  main  spool  directory used by
	rpc.pcnfsd to world writeable.   To exploit this, an  attacker
	could     locally     set     a     symbolic     link     from
	/var/spool/pcnfsd/printername to any other file on the system.
	Calling pr_init ()  with the name  of the symbolically  linked
	file will force  rpc.pcnfsd to follow  the symlink and  change
	the destination file to mode 777.

    run_ps630 ()
    ------------
	Upon system bootup, rpc.pcnfsd  is started from the  system rc
	files which  are executed  from the  / directory.   Because of
	this,  rpc.pcnfsd  will  attempt  to  function out of the root
	directory  (/).   When  run_ps630  ()  is  called,   it  calls
	suspicious () to check for any insecure characters.  The  list
	of characters that secure () checks for are:

	;|&<>`'!?*()[]^/

	If it detects that none of these characters are being used, it
	will call strcat ()  to append the data  to a buffer and  then
	run the data contained inside it with system ().  By sending a
	\ncommand\n as the  printer, "." as  the spool directory,  and
	setting your client options  to "d", arbitary commands  can be
	executed remotely on the server as root.

    NOTE: AIX is  not vulnerable to  problem with pr_init()  and HP is
    only vulnerable to pr_init() function in HP-UX 9.0, 10.0.

    Rhino9  Security  Advisory  pointed  out yet three vulnerabilities
    (Author - horizon).

    pr_cancel
    ---------
	As  pointed  out  in  the  Repsec  advisory,  the suspicious()
	function  does  not  check  for several shell meta-characters,
	which allows the newline,  and on some operating  systems, the
	'/' character to be passed.  This allows for the  exploitation
	of the run_ps630 system() call, as documented in the advisory.
	However,  this  oversight  in  the  suspicious() function also
	allows for an attacker to manipulate the pr_cancel()  function
	to gain access to the machine.  Specifically, an attacker will
	have to invoke  pr_cancel with a  valid printer name,  a valid
	user name,  and a  printer id  containing the  crafted exploit
	string.   The   printer  id   will  be   passed  through   the
	suspicious() function,  and then  run through  a shell  in the
	su_popen() function.  As far as obtaining a valid printer  id,
	some  implementations  unilaterally  accept  "lp"  as  a valid
	printer, but  this is  not a  concern because  the attack  can
	request a  list of  the valid  printers with  the pr_list  RPC
	call.  As the third vulnerability addresses, it is easy for an
	attacker to get a list of valid usernames out of rpc.pcnfsd.

    get_pr_status
    -------------
	The get_pr_status function  uses popen() directly,  as opposed
	to calling the su_popen() function. The OpenBSD implementation
	of rpc.pcnfsd does not check if the supplied printer name is a
	valid printer; it only checks if the name is suspicious. Thus,
	a printer name can be  provided such that remote commands  can
	be executed as root.   It is very important  to note that  the
	OpenBSD team is well aware of the problems with rpc.pcnfsd and
	that this  vulnerability is  in no  way an  indication of  any
	oversight  or  negligence  on  their  part.   The man page for
	rpc.pcnfsd on OpenBSD gives a  very strong warning not to  use
	the program, because of numerous known security flaws.   Their
	auditing efforts have wisely been placed in the more  critical
	programs.

    mapid / auth - All implementations are vulnerable
    ------------
	This is a more difficult problem in scope because it addresses
	the inherent functionality of the daemon. Any attacker can use
	the mapid() functionality of rpc.pcnfsd to retrieve a list  of
	the usernames on a system.  The far more serious hole  is that
	an  attacker  can  use  the  authentication  functionality  to
	attempt to guess  passwords. These password  guessing attempts
	are not logged in any  implementation we have looked at.   The
	only  logging  that  occurs  is  when the attacker succesfully
	guesses a password.   Upon this occurance,  a single entry  is
	placed in wtmp.  It is  easy to write a program to  attempt to
	brute force passwords, working from  a list.  Also, there  are
	no slowdowns  built into  the program  to prevent  rapid brute
	force attacks.  Some implementations  do not  allow logins  of
	UID's below a certain number.

    The pr_cancel  vulnerability will  allow a  remote user  to obtain
    non-root  access  to  most  machines  running rpc.pcnfsd.  Notable
    exceptions  are  NetBSD,  which  has  a  very  strict suspicious()
    function, and  later versions  of the  Solaris package,  which use
    single quotes  around the  arguments in  it's popens.   Also, some
    machines will allow  remote root access,  but most likely  none of
    the current implementations.

    The get_pr_status  vulnerability will  allow a  remote attacker to
    obtain  root  access  to  an  OpenBSD  machine  and possibly older
    machines running BSD based implementations of pcnfsd.

    The  mapid/auth  vulnerability  will  allow  an  attacker  to gain
    valuable information about a machine.  Furthermore, if the machine
    has unpassworded or weakly passworded accounts, they can be easily
    guessed, with very little logging of malicious action.

    One  will  need  to  setup  this  exploit.   This  sploit  can  be
    configured to do one of two things:

        - send you back an xterm
        - rcp a .rhosts and a file from somewhere

    Read the first couple of lines. You will need to define a host  to
    send the xterm back to, or define an account that you will use  to
    rcp from.  The best way to do option B is to pick a random account
    somewhere, put  in a  .rhosts and  a file  like blah.tar.gz.  Then
    configure the sploit to copy the .rhosts and the blah.tar.gz.  Run
    said  exploit,  rsh  in,  untar  bag  of  toys, grab root, install
    trojans,  log  out,  and  then  log  back  in as root (if you have
    permissions to that  in first place).   If your file  is big,  you
    might need to crank up the timeout value.
