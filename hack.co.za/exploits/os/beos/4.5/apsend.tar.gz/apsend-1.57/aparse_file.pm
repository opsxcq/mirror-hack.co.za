use vars qw(@ISA @EXPORTER @EXPORT_OK);
use Exporter;

@ISA=qw(Exporter);
@EXPORT=qw(parse_file);


# Parse file $file (not implemented)...
sub parse_file {
 die("Sorry, scripting language isn't implemented yet !!!\n\n");
}

1;
