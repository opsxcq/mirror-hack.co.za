/********************************************************************
  Tester for the Exploit which tests buffer overflows on SunOs 4.1.x
  This program only copies an argument into a local buffer in its
  stack, but when filled with some code well placed, it executes it.

  Here is an example about the testing of the exploiter:

      ./victim `./sparc 1024 -0x430`

  This program can be compiled with any optimization method without
  being affected.

  Warning: it is not the foobar() function which executes the stack
  on return, but main(). foobar() modifies main's return pointer.
  I couldn't find a way to modify foobar's return pointer since it
  is stored in the register %i7.


                      Willy Tarreau
                      tarreau@aemiaif.ibp.fr
		      http://www-miaif.ibp.fr/willy/
**********************************************************************/
#include <stdio.h>

char *argv2;

main(int argc,char **argv) {

    argv2=argv[1];
    fprintf(stderr,"strlen(argv)=%d\n",strlen(argv[1]));
    foobar();
    return 0;
}

char *foobar() {
  char s[1024];

  fprintf(stderr,"&s=%08X, strlen(argv)=%d\n",s,strlen(argv2));
  strcpy(s,argv2);
  return s;
}

