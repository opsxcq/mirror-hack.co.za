#!/bin/bash

cd /home/bulba/
mkdir wuwu
cd wuwu

HEH=`perl -e 'print "A" x 255'`

 A=0
 while [ 15 -gt $A ]; do
 mkdir $HEH
 cd $HEH
 let A=A+1
 done


