Remote.exe - NetWare 4.11+4.1 Remote.NLM password decrypter.
Remote.pas - Pascal source code.
Hash.txt   - Password hash table (see source code for purpose/usage).

"Some OTHER operating systems suffer from weak password encryption."
- A quote from Novell's course of Networking Technologies.
