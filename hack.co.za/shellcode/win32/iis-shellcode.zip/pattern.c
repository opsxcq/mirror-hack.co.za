/* 
 * Pattern generator for exploits.
 *
 *  �zg�r Kesim 1999
 */

#include <stdio.h>

int 
main (int argc, char **argv)
{
  char *pattern;
  int length, i;
  char back = 'z';
  char forw = 'A';

  if (argc < 2)
    return 1;

  length = atoi (argv[1]);
  pattern = (char *) malloc(length * sizeof(char) + 1);
  for (i = 0; i < length; i += 4)
    {
      pattern[i] = back;
      pattern[i + 1] = forw;
      pattern[i + 2] = forw + 1;
      pattern[i + 3] = forw + 2;

      if (++forw == 'Y')

	{
	  forw = 'A';
	  if (--back < 'a')
	    back = 'a';
	}
    }
  printf("%s\n",pattern);
  return 0;
}
